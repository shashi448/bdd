package com.sapcare.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SapcareLogin {

	WebDriver driver;

	@FindBy(id = "sap-user")
	private WebElement username;

	@FindBy(id = "sap-password")
	private WebElement password;

	@FindBy(xpath = "//a[@id='LOGON_BUTTON']/span/span")
	private WebElement logonButton;

	@FindBy(id = "ZTMUS_SUPGEN")
	private WebElement generalSuperUser;

	@FindBy(id = "SESSION_QUERY_CONTINUE_BUTTON")
	private WebElement continueButton;

	public SapcareLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void sapCareLogin(String user1, String pwd1) {
		username.sendKeys(user1);
		password.sendKeys(pwd1);
		logonButton.click();
		try {
			continueButton.click();
		} catch (Exception e) {

		}
		generalSuperUser.click();

	}

}
