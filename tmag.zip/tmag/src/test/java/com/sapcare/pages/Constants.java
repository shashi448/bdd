package com.sapcare.pages;

public enum Constants {
	Pending, complete
}
