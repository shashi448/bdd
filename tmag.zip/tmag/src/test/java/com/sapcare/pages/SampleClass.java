package com.sapcare.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleClass {
	public static WebDriver driver;

	public static void main(String[] args) throws Exception {
		driver = new ChromeDriver();
		driver.get(
				"http://qatspcu026.unix.gsm1900.org:8000/sap(bD1lbiZjPTIwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?sap-client=200&sap-language=EN");
		new SapcareLogin(driver).sapCareLogin("nluhadi", "August_2017");
		driver.switchTo().frame("CRMApplicationFrame").switchTo().frame(2).switchTo().frame("CRMApplicationFrame")
				.switchTo().frame("FRAME_APPLICATION").switchTo().frame("WorkAreaFrame1");
		driver.findElement(By.xpath("//*[@id='C4_W17_V18_ZSHOP']")).click();
		Thread.sleep(6000);
		driver.findElement(By.xpath("//*[@id='C18_W66_V67_V68_BYOD']/span/b")).click();
		
	}

}
