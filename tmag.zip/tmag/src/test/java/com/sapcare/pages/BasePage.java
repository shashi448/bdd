package com.sapcare.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BasePage {
	public final Logger log = LoggerFactory.getLogger(BasePage.class);

	protected WebDriver driver;

	public BasePage(WebDriver webDriver) {

		this.driver = webDriver;
	}

	public boolean isAlertPresent() {
		boolean foundAlert = false;
		WebDriverWait wait = new WebDriverWait(driver, 10);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (TimeoutException e) {
			log.info("Alert not present: " + e);
		}
		return foundAlert;
	}

	protected void waitForPageToLoad() {
		try {
			new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
					.executeScript("return document.readyState").equals(Constants.complete.toString()));
		} catch (Exception e) {
			isAlertPresent();
			log.info("Wait for page to load failed with exception: " + e);
		}
	}

	protected void waitForClick(WebElement ele, int time) {

		try {
			new WebDriverWait(driver, time).until(ExpectedConditions.elementToBeClickable(ele));
		} catch (Exception e) {
			log.info("Exception in wait for clickable: " + e);
			MatcherAssert.assertThat(ele + " is not clickable within " + time + " seconds.", false);
		}
	}

}
