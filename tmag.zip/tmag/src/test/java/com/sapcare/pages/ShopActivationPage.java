package com.sapcare.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ShopActivationPage extends BasePage {

	WebDriver driver;

	@FindBy(id = "C4_W17_V18_ZSHOP")
	private WebElement shopActivationPage;

	@FindBy(id = "C18_W66_V67_V68_BYOD")
	private WebElement byodPage;

	@FindBy(id = "C21_W84_V85_V86_ztcnsim_zpostalcode")
	private WebElement zipCode;

	@FindBy(id = "C21_W84_V85_V86_ztcnsim_newiccid")
	private WebElement virtualIccid;

	@FindBy(id = "C21_W84_V85_V86_ztcnsim_zsim")
	private WebElement simIccid;

	@FindBy(id = "C21_W84_V85_V86_ztcnsim_attr1")
	private WebElement imeiNumber;

	@FindBy(id = "//*[@id='CRMMessageLine1']/span[4]")
	private WebElement ErrorText;

	String errorText = "The simNumber/IMSI you have requested does not exi st";

	public ShopActivationPage(WebDriver driver) {
		super(driver);
	}

	public void navigateToByodPage() {
		driver.switchTo().frame("CRMApplicationFrame").switchTo().frame(2).switchTo().frame("CRMApplicationFrame")
				.switchTo().frame("FRAME_APPLICATION").switchTo().frame("WorkAreaFrame1");
		shopActivationPage.click();
		waitForPageToLoad();
		waitForClick(byodPage, 10);
		byodPage.click();

	}
}
