package com.tmo.tmag.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by spachava on 6/21/2017.
 */

public class LoginPage extends BasePage {
	
	@FindBy(css="#username")
	private WebElement userName;
	
	@FindBy(css="#password")
	private WebElement password;
	
	@FindBy(css="#loginButton")
	private WebElement loginButton;
	
	@FindBy(css="#twotabsearchtextbox")
	private WebElement searchBox;
	
	@FindBy(css="[id*='issDi']")
	private WebElement results;
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}

    public HomePage doLogin() {
        setValue(searchBox, "iPhone7");
        /*setValue(userName, "betamngr");
        setValue(password, "betamngr");
        click(loginButton);*/
        return get(HomePage.class);
    }
    
    public LoginPage openAmazon() {
        getDriver().get("https://www.amazon.com/");
        /*setValue(userName, "betamngr");
        setValue(password, "betamngr");
        click(loginButton);*/
        return this;
    }
    
    public LoginPage doSearch() {
        setValue(searchBox, "iPhone7");
        /*setValue(userName, "betamngr");
        setValue(password, "betamngr");
        click(loginButton);*/
        return this;
    }
    
    public LoginPage results() {
    	results.getSize();
    	return this;
    }
}
