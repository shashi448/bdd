package com.tmo.tmag.prepaid.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.pages.pos.PosHomepage;
import com.tmo.pages.tmag.PrepaidMenuPage;

public class TmagHomePagePrepaid extends TmagLoginPage {

	@FindBy(css = "#logOut")
	private WebElement logoutLnk;

	@FindBy(css = "#appLinkPrepaidMenu")
	private WebElement prepaidMenuLnk;

	@FindBy(css="#storeinfo")
	private WebElement storeInfo;

	public TmagHomePagePrepaid(WebDriver driver) {
		super(driver);
	}

	public TmagHomePagePrepaid validateStoreAndTill() {
		MatcherAssert.assertThat("Store Is Open", storeInfo.getText().contains(PosHomepage.storeValue));
		return this;
	}

	public PrepaidMenuPage clickPrepaidMenuLnk() {
		try{
			waitAndClick(prepaidMenuLnk, 30);
		}
		catch (Exception e) {
			MatcherAssert.assertThat(prepaidMenuLnk + " is not visible within 60 seconds.", false);
			throw new RuntimeException(e);
		}
		return get(PrepaidMenuPage.class);
	}
}
