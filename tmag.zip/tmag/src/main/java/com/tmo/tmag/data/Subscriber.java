package com.tmo.tmag.data;

import java.util.LinkedHashSet;

public class Subscriber {

	private LinkedHashSet<Line> lines = new LinkedHashSet<Line>();
	private String ban;
	private String ssn;
	
	public Subscriber(String ban){
		this.ban = ban;
	}
	
	public String getMsisdn(){
		return getLine().getMsisdn();
	}
	
	public Line getLine(){
		return lines.iterator().next();
	}
	
	public void addLine(Line line){
		this.lines.add(line);
	}
	
	public void removeLine(Line line){
		for(Line sub : lines){
			if(sub.getMsisdn().equals(line.getMsisdn()))
				lines.remove(sub);
			break;
		}
	}
	
	public LinkedHashSet<Line> getLines() {
		return lines;
	}
	public void setLines(LinkedHashSet<Line> lines) {
		this.lines = lines;
	}
	public String getBan() {
		return ban;
	}
	public void setBan(String ban) {
		this.ban = ban;
	}
	public String getSsn() {
		return ssn;
	}
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
	
	
}
