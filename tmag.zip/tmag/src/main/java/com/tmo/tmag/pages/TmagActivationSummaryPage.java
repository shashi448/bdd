package com.tmo.tmag.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * TMAG Activation Summary Page Object Model.
 * @author Prince
 *
 */
public class TmagActivationSummaryPage extends TmagBillingInfoPage {

	@FindBy(css="#nextButton")
	private WebElement btnActivateAndContinue;
	
	@FindBy(css="input[id='quoteTool']")
	private WebElement btnCostcoContinue;
	
	public TmagActivationSummaryPage(WebDriver driver) {
		super(driver);
	}
	
	public TmagActivationSummaryPage activateAndContinue() {
		verifyPageLoad("TMAG Activation Summary");
		click(btnActivateAndContinue);
		return this;
	}
	
	public TmagActivationSummaryPage actContinue() {
		verifyPageLoad("TMAG Activation Summary");
		click(btnCostcoContinue);
		return this;
	}
	
	
	
	
	

}
