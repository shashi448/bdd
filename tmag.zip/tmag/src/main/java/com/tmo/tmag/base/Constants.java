package com.tmo.tmag.base;

public enum Constants {
	Pending,complete
}
