package com.tmo.tmag.pages;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.pages.base.TmagConstants;

/**
 * TMAG Features Page Object Model.
 * 
 * @author Prince
 *
 */
public class TmagFeaturesPage extends TmagRatePlanAndDeviceSelectionPage {

	@FindBy(css = "div[id='-1'][soc='php']")
	private WebElement btnDeclineSOC;

	@FindBy(css = "div[id='PHPBNDL'][soc='php']")
	private WebElement btnPremDevProtectionSOC;

	@FindBy(css = "div[class='featureButton'][id='-1'][soc='php']")
	private WebElement btnDeclinePooledSOC;

	@FindBy(css = "div#phpPaginator>div.nextPage")
	private WebElement btnMoveToSecPage;

	@FindBy(css = "#nextButton")
	private WebElement btnContinueToServiceSetup;
	
	@FindBy(css = "button[class='walkme-custom-balloon-button walkme-custom-balloon-normal-button walkme-custom-balloon-next-button walkme-action-next walkme-click-and-hover']")
	private WebElement btnAddFeatureNext;

	public TmagFeaturesPage(WebDriver driver) {
		super(driver);
	}

	/**
	 * Recursively checks if decline soc button is displayed, then clicks when
	 * found.
	 * 
	 * @return TmagFeaturesPage instance.
	 */
	public TmagFeaturesPage isDeclineSocDisplayed() {
		verifyPageLoad("TMAG Features");
		if (isElementPresent(btnDeclineSOC)) {
			click(btnDeclineSOC);
		} else {
			click(btnMoveToSecPage);
			isDeclineSocDisplayed();
		}
		return this;
	}

	public TmagFeaturesPage isFeaturesSocDisplayed() {
		verifyPageLoad("TMAG Features");
		if (isElementPresent(btnPremDevProtectionSOC)) {
			click(btnPremDevProtectionSOC);
		} else {
			click(btnMoveToSecPage);
			isFeaturesSocDisplayed();
		}
		return this;
	}

	/**
	 * Button to continue to next page.
	 * 
	 * @return TmagFeaturesPage instance.
	 */
	public TmagFeaturesPage continueToServiceSetup() {
		click(btnContinueToServiceSetup);
		if (isElementPresent(btnAddFeatureNext)) {
			click(btnAddFeatureNext);
		}
		return this;
	}

	public TmagFeaturesPage selectFeatures(String scenario) {
		try {
			if (TmagConstants.SCN_AAGSMIRNonPooledEIP.equals(scenario)) {
				isDeclineSocDisplayed();
			} else if (TmagConstants.SCN_AAGSMIRPooledFRP.equals(scenario)) {
				if (isElementPresent(btnDeclinePooledSOC)) {
					click(btnDeclinePooledSOC);
				}
			} else if (TmagConstants.SCN_AAMBIRNonPooledEIP.equals(scenario)) {
				isDeclineSocDisplayed();
			} else if (TmagConstants.SCN_AAMBIRNonPooledEIPPRMArket.equals(scenario)) {
				isDeclineSocDisplayed();
			}
			continueToServiceSetup();
		} catch (Exception e) {
			System.out.println("Error in Features selection" + e.getMessage());
		}
		return this;
	}
}
