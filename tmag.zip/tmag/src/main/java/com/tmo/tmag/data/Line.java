package com.tmo.tmag.data;

public class Line {
	
	private String msisdn;

	public Line(String msisdn){
		this.msisdn = msisdn;
	}
	
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

}
