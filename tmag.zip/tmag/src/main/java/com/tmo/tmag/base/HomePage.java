package com.tmo.tmag.base;

import org.openqa.selenium.WebDriver;

public class HomePage extends LoginPage{

	public HomePage(WebDriver driver) {
		super(driver);
	}

}
