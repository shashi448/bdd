package com.tmo.tmag.base;

import org.openqa.selenium.WebDriver;

import com.tmo.data.ALMData;
import com.tmobile.eqm.testfrwk.ui.core.httpclient.TEPService;

public class BaseSystem {

	protected WebDriver driver;
	
	static {
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/drivers/chromedriver.exe");
		System.setProperty("webdriver.ie.driver", "./src/test/resources/drivers/IEDriverServer.exe");
		System.setProperty("webfriver.firefox.driver", "./src/test/resources/drivers/geckodriver.exe");
	}
	
	public BaseSystem(WebDriver webDriver) {
		this.driver = webDriver;
	}
	
	public void open(String arg) {
		switch (arg) {
		case "TMAGRetail":
			driver.get("https://qattmag521.unix.gsm1900.org:8002/WatsonLogin.jsp");
			break;
			
		case "QVRetail":
			driver.get("https://qattnac124.unix.gsm1900.org:7888/prepaid-web/");
			break;
			
		case "POS":
			driver.get("https://qatwsposx521.gsm1900.org:7101/");
			break;

		default:
			break;
		}
	}
	public void close() {
		driver.quit();
	}
	
	private void deleteAllCookies(){
		driver.manage().deleteAllCookies();
	}
	
	public void updateALM(ALMData data) {
		TEPService alm = new TEPService();
		alm.createAlmUpdate(data.getDomain(), data.getProject(), data.getTestId(), data.getTestSetId(), data.getTestExecutionResult(), data.getTestDuration());
	}
}
