package com.tmo.tmag.pages;

import java.util.concurrent.TimeUnit;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tesa.pages.TesaIngenicoPrintDocumentPage;

public class TmagActivationConfirmationPage extends TesaIngenicoPrintDocumentPage {
	
	@FindBy(css="#nextButton")
	private WebElement btnContinueToWorkstationPos;
	
	@FindBy(css="#billingActNo")
	private WebElement activatedBan;
	
	@FindBy(css="div[id='billingActNo']")
	private WebElement fldAccountNumber;

	public TmagActivationConfirmationPage(WebDriver driver) {
		super(driver);
	}
	
	public TmagActivationConfirmationPage isActivationSuccessful(String ban, String msisdn) {
		try{
			log("TMAG activation confirmation scenario started");
			verifyPageLoad("TMAG Activation Confirmation");
			if (isElementPresent(btnContinueToWorkstationPos)) {
				ban = fldAccountNumber.getText();
				msisdn = driver.findElement(By.xpath("//table/tbody/tr/td[2]")).getText();
				log("BAN:    " + ban);
				log("MSISDN: " + msisdn);
				waitAndClick(btnContinueToWorkstationPos,30);
				log("Clicked Continue to Workstation button.");
				if(isAlertPresent()) {
					acceptAlert();
				}
				log.info("Activation is successful");
				MatcherAssert.assertThat("Activation Success, Payment pending, toggling to POS.", true);
				}
			else {
				log.info("Activation Failed");
				MatcherAssert.assertThat("Activation failed on confirmation screen.", false);
			}
		}catch (Exception e) {
		 log("TMAG activation confirmation failed");
		 MatcherAssert.assertThat("isActivationSuccessful failed.", false);
		}
		return this;
	}
}
