package com.tmo.tmag.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.Properties;

public class TmagActivationSummaryResultsPage extends TmagActivationSummaryPage {

	@FindBy(css = "div[class='welcomeMessage']")
	private WebElement frmActivation;

	@FindBy(css = "#rejectReason")
	private WebElement drpdwnRejectReason;

	@FindBy(css = "#quoteToolComplete")
	private WebElement btnCotninuetoAgreement;

	@FindBy(css = "input[id='nextButton']")
	private WebElement btnReturnToMainPage;

	public TmagActivationSummaryResultsPage(WebDriver driver) {
		super(driver);
	}

	public TmagActivationSummaryResultsPage verifySuccessfulActivation() {
		try{
			log("TMAG activation summary - Email capture & activation validation started");
			if ("Email Capture".equals(getDriver().getTitle())) {
				log.info("Activation completed.");
				MatcherAssert.assertThat("Activation Success, toggled to POS", true);
			} else {
				log.info("Activation failed");
				MatcherAssert.assertThat("Activation Failure", false);
			}
		}catch (Exception e) {
		 log("Activation validation failed.");
		 MatcherAssert.assertThat("Activation validation failed.", false);
		}
		return this;	
	}

	public TmagActivationSummaryResultsPage verifyCstSuccessfulActivation() {
		try{
			log("TMAG activation summary - Email capture & activation validation started");
			waitFor(frmActivation, 20);
			if ("Activation completed.".equals(frmActivation.getText())) {
				log.info("Activation completed.");
				MatcherAssert.assertThat("Activation Success, toggled to POS", true);
			} else {
				log.info("Activation failed");
				MatcherAssert.assertThat("Activation Failure", false);
			}
		}catch (Exception e) {
		 log("Activation validation failed.");
		 MatcherAssert.assertThat("Activation validation failed.", false);
		}
		return this;	
	}

	public TmagActivationSummaryResultsPage deviceTradeInProgram() {
		try{
			log("Device trade-in - selection started");
			if (drpdwnRejectReason.isDisplayed()) {
				drpdwnRejectReason.sendKeys("Does not have a device");
				log("Device trade-in action completed.");
				switchToDefault();
			}
		}catch (Exception e) {
		 log("Device trade-in - selection failed.");
		 MatcherAssert.assertThat("device Trade-In Program failed.", false);
		}
		return this;	
	}

	public void clickContinueToAgreements() {
		try{
			log("Device trade-in - selection started");
			log("reached continue to agreements");
			waitAndClick(btnCotninuetoAgreement, 30);
			log("");
		}catch (Exception e) {
		 log("Click to Agreements failed.");
		 MatcherAssert.assertThat("clickContinueToAgreements failed.", false);
		}
	}

	public TmagActivationSummaryResultsPage returnToMainMenu() {
		try{
			log("Click to return for main menu started");
			if (btnReturnToMainPage.isDisplayed()) {
				btnReturnToMainPage.click();
				log.info("Execution Complete");
				MatcherAssert.assertThat("Execution Completed", true);
			} else {
				log.info("Return to main menu");
				MatcherAssert.assertThat("Return to main menu click Failure", false);
			}
		}catch (Exception e) {
		 log("After activation, click to navigate main menu failed.");
		 MatcherAssert.assertThat("returnToMainMenu failed.", false);
		}
		return this;
	}
}
