package com.tmo.tmag.prepaid.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.pages.tmag.PrepaidMenuPage;

public class TmagCustomerInformationPage extends PrepaidMenuPage{
	//region
	@FindBy(css="select[name='market']")
	private WebElement custMarket;

	@FindBy(css="input[name='birthdate']")
	private WebElement txtDOB;

	@FindBy(css="input[name='j_password'][type='password']")
	private WebElement txtPIN;

	@FindBy(css="#f_Name")
	private WebElement txtFirstName;

	@FindBy(css="#l_Name")
	private WebElement txtLastName;

	@FindBy(css="input[name='welcomeEmail'][class='iopt']")
	private WebElement txtWelcomeEmail;

	@FindBy(css="frame[name='prepaidnav']")
	private WebElement frameprenav;

	@FindBy(css="input[name='nextButton']")
	private WebElement btnNext;
	
	@FindBy(css="frame[name='middle']")
	private WebElement middleFrame;

	public TmagCustomerInformationPage(WebDriver driver) {
		super(driver);
	}

	public TmagRatePlanFeatures customerInformation(String customerMarket, String birthDate, String pin) {
		try {
			if (isAlertPresent()) {
				getDriver().switchTo().alert().accept();
			}
			getDriver().switchTo().defaultContent();
			switchFrame(middleFrame);
			waitFor(txtPIN);
			waitFor(txtDOB);
			waitFor(custMarket);
			setValue(custMarket, customerMarket);
			//custMarket.sendKeys(customerMarket);
			setValue(txtDOB, birthDate);
			setValue(txtPIN, pin);
			//waitFor(txtFirstName); txtFirstName.clear(); txtFirstName.sendKeys("");
			//waitFor(txtLastName); txtLastName.clear(); txtLastName.sendKeys("");
			waitFor(txtWelcomeEmail); txtWelcomeEmail.clear(); txtWelcomeEmail.sendKeys("Srinivasa.Pachava@T-Mobile.com");
			getDriver().switchTo().defaultContent();
			nextButtonClk();
			log("Customer Information Next Button: Click");
		}
		catch (Exception e) {
			log("Customer Information Next Button Click - Fail");
			MatcherAssert.assertThat("Customer Information Next Button Click - Fail", false);
			close();
			throw new RuntimeException(e);
		}
		return get(TmagRatePlanFeatures.class);
	}
	public void nextButtonClk() {
		switchFrame(frameprenav);
		waitAndClick(btnNext, 60);
	}
}