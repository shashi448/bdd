package com.tmo.tmag.system;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;

import com.tmo.tmag.pages.TmagHomePage;
import com.tmo.tmag.pages.TmagRatePlanAndDeviceSelectionPage;
import com.tmo.tmag.pages.TmagServiceSetup;
import com.tmo.tmag.prepaid.pages.TmagLoginPage;
import com.tmo.pages.pos.PosAddTenderPage;
import com.tmo.pages.pos.PosCalculatePaymentsPage;
import com.tmo.pages.pos.PosCustomerOverviewPage;
import com.tmo.pages.pos.PosItemEntryPage;
import com.tmo.tesa.pages.TesaEmailValidatePage;
import com.tmo.tesa.pages.TesaFinalConfirmationPage;
import com.tmo.tesa.pages.TesaIngenicoPrintDocumentPage;
import com.tmo.tmag.pages.TmagActivationConfirmationPage;
import com.tmo.tmag.pages.TmagActivationSummaryPage;
import com.tmo.tmag.pages.TmagActivationSummaryResultsPage;
import com.tmo.tmag.pages.TmagBillingInfoPage;
import com.tmo.tmag.pages.TmagCustomerCreditEntryPage;
import com.tmo.tmag.pages.TmagCustomerCreditResultsPage;
import com.tmo.tmag.pages.TmagFeaturesPage;

public class ActivationSystem extends LoginSystem {
	
	private TmagHomePage tmagHome; // = new TmagHomePage(driver);
	private TmagCustomerCreditEntryPage tmagCreditEntry = new TmagCustomerCreditEntryPage(driver);
	private TmagCustomerCreditResultsPage tmagCreditResults = new TmagCustomerCreditResultsPage(driver);
	private TmagRatePlanAndDeviceSelectionPage tmagRatePlanDevice = new TmagRatePlanAndDeviceSelectionPage(driver);
	private TmagFeaturesPage tmagFeatures = new TmagFeaturesPage(driver);
	private TmagServiceSetup tmagServiceSetup = new TmagServiceSetup(driver);
	private TmagBillingInfoPage tmagBillingInfo = new TmagBillingInfoPage(driver);
	private TmagActivationSummaryPage tmagActivationSummary = new TmagActivationSummaryPage(driver);
	private TmagActivationSummaryResultsPage tmagActivationResults = new TmagActivationSummaryResultsPage(driver);
	private TesaEmailValidatePage tesaEmailValidate = new TesaEmailValidatePage(driver);
	private TmagActivationConfirmationPage tmagActivationConfirmation = new TmagActivationConfirmationPage(driver);
	private TesaIngenicoPrintDocumentPage tesaPrintDoc = new TesaIngenicoPrintDocumentPage(driver);
	private PosCustomerOverviewPage posCustOverview = new PosCustomerOverviewPage(driver);
	private PosItemEntryPage posItemEntry = new PosItemEntryPage(driver);
	private PosCalculatePaymentsPage posCalcPayments = new PosCalculatePaymentsPage(driver);
	private PosAddTenderPage posAddTender = new PosAddTenderPage(driver);
	private TesaFinalConfirmationPage tesaFinalConfirmation = new TesaFinalConfirmationPage(driver);
	private String activatedBan = "";
	private String activatedMsisdn = "";
	
	public ActivationSystem(WebDriver webDriver) {
		super(webDriver);
	}
	
	public void changeStore() {
		//tmagHome.changeStore();
	}

	public void personalAccoutCreditCheck(String ssn) {
		tmagHome = new TmagHomePage(driver).newPersonalAccount();
			try{
				tmagCreditEntry.creditAuthorization();
				tmagCreditEntry.fillForm(ssn);
				tmagCreditEntry.performCreditCheckAndContinue();			
			}catch (Exception e) {
				log("personalAccoutCreditCheck failed");
				MatcherAssert.assertThat("personalAccoutCreditCheck is not completed.", false);
			}
		}

	public void linesToActivate() {
		try{
			tmagCreditResults.continueToNextPage();		
		}catch (Exception e) {
			log("linesToActivate failed");
			MatcherAssert.assertThat("linesToActivate is not completed.", false);
		}
	}
	
	public void selectPricingOption(String arg1){
			try{
				tmagRatePlanDevice.selectPricingOptions(arg1);
			}catch (Exception e) {
				log("selectPricingOption failed");
				MatcherAssert.assertThat("selectPricingOption did not select the price as expected.", false);
			}
		}
	
	public void enterDeviceDetails(String sim) {
		try{
			tmagRatePlanDevice.enterImei();
			tmagRatePlanDevice.enterSim(sim);
			tmagRatePlanDevice.enterSku();
			tmagRatePlanDevice.validateDevice();
			tmagRatePlanDevice.continueToFeatures();
		}catch (Exception e) {
			log("enterDeviceDetails failed");
			MatcherAssert.assertThat("SIM/IMEI/SKU validation failed.", false);
		}
	}
	
	public void declineProtectionAndContinue() {
		try{
			tmagFeatures.isDeclineSocDisplayed();
			tmagFeatures.continueToServiceSetup();
		}catch (Exception e) {
			log("declineProtectionAndContinue failed");
			MatcherAssert.assertThat("Device protection selection failed.", false);
		}
	}
	
	public void acceptProtectionAndContinue() {
		try{
			tmagFeatures.isFeaturesSocDisplayed();
			tmagFeatures.continueToServiceSetup();
			}catch (Exception e) {
			log("acceptProtectionAndContinue failed");
			MatcherAssert.assertThat("Accept Device protection selection failed.", false);
		}
	}
	
	public void e911Disclaimer() {
		try{
			tmagServiceSetup.acceptDisclaimer();
		}catch (Exception e) {
			log("e911Disclaimer failed");
			MatcherAssert.assertThat("911 check mark failed.", false);
		}
	}

	public void chooseAreaCode(String arg1) {
		try{
			tmagServiceSetup.selectAreaCode(arg1);
			tmagServiceSetup.continueToBillingInfo();
			continueFlow();
		}catch (Exception e) {
			log("chooseAreaCode failed");
			MatcherAssert.assertThat("Area code selection and payment validations failed.", false);
		}
	}
	
	public void chooseAreaCodeCostco(String arg1) {
		try{
			tmagServiceSetup.selectAreaCode(arg1);
			tmagServiceSetup.continueToBillingInfo();
			continueFlowCostco();
		}catch (Exception e) {
			log("chooseAreaCodeCostco failed");
			MatcherAssert.assertThat("Area code selection and payment validations failed.", false);
		}
	}
	
	public void itemEntry() {
		try{
			posCustOverview.continueCustomerInformation();
		}catch (Exception e) {
			log("itemEntry failed");
			MatcherAssert.assertThat("itemEntry button click failed.", false);
		}
	}
	
	private void continueFlow() {
		try{
			tmagBillingInfo.unEnrollAutoPay();
			tmagBillingInfo.continueToSummary();
			tmagActivationSummary.activateAndContinue();
			tmagActivationResults.verifySuccessfulActivation();
			tesaEmailValidate.validateContinueEmail();
			tesaPrintDoc.closeAndContinue();
			tmagActivationConfirmation.isActivationSuccessful(activatedBan, activatedBan);
			posCustOverview.acceptIngenicoNotConnnected();
			activatedBan = posCustOverview.getBan();
			activatedMsisdn = posCustOverview.getMSISDN();
			posCustOverview.continueCustomerInformation();
			posItemEntry.continueCalculateWithPayments();
		}catch (Exception e) {
			log("Autopay and summary confirmations failed");
			MatcherAssert.assertThat("Continue workflow for activation and sumaary confirmation failed.", false);
		}
	}
	
	private void continueFlowCostco() {
		try{
			tmagBillingInfo.unEnrollAutoPayCostco();
			tmagBillingInfo.continueToSummary();
			tmagActivationSummary.activateAndContinue();
			tmagActivationResults.verifyCstSuccessfulActivation();
			tesaEmailValidate.validateCostcoContinueEmail();
			tesaEmailValidate.deviceTradeInProgram();
			tesaEmailValidate.clickContinueToAgreements();
			tesaPrintDoc.signDocumentVerifyAndFinish();
		}catch (Exception e) {
			log("Autopay and summary confirmations failed");
			MatcherAssert.assertThat("Continue workflow for activation and sumaary confirmation failed.", false);
		}
	}
	
	public void addDownPayment(String downPaymentAmount) {
		try{
			posCalcPayments.calculatePaymentsAndContinue(downPaymentAmount);
		}catch (Exception e) {
			log("addDownPayment failed");
			MatcherAssert.assertThat("addDownPayment failed.", false);
		}
	}
	
	public void clickCalculateContinue() {
		try{
			posCalcPayments.clickPrepaidCalculateAndContinue();
		}catch (Exception e) {
			log("clickCalculateContinue failed");
			MatcherAssert.assertThat("clickCalculateContinue failed.", false);
		}
	}
	
	public void selectTenderType() {
		try{
			posAddTender.selTenderType();
		}catch (Exception e) {
			log("selectTenderType failed");
			MatcherAssert.assertThat("Tender Type selection failed.", false);
		}
	}
	
	public void addPaymentTender() {
		try{
			posAddTender.addTender();
			posAddTender.handlePopups();
		}catch (Exception e) {
			log("addPaymentTender failed");
			MatcherAssert.assertThat("adding Payment Tender type failed.", false);
		}
	}
	
	public void finishActivation() {
		try{
			tesaFinalConfirmation.isActivationSuccessful(activatedBan, activatedMsisdn);	
		}catch (Exception e) {
			log("finishActivation failed");
			MatcherAssert.assertThat("Activation complete validation failed.", false);
		}
	}
		//tesaEmailValidate.skipAndContinue();
	
	public void finishPostpaidActivation() {
		try{
			tesaEmailValidate.closeReceipt();
			tesaEmailValidate.skipAndCompleteAct();
		}catch (Exception e) {
			log("finishPostpaidActivation failed");
			MatcherAssert.assertThat("Postpaid activation validation failed.", false);
		}
	}
	
	public void ActivationSystem() {
		try{
			tesaFinalConfirmation.isActivationSuccessful(activatedBan, activatedMsisdn);
		}catch (Exception e) {
			log("enterDeviceDetails failed");
			MatcherAssert.assertThat("SIM/IMEI/SKU validation failed.", false);
		}
	}
}
