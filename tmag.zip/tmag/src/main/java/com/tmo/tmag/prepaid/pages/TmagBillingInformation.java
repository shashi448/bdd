package com.tmo.tmag.prepaid.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.pages.TmagServiceSetup;

/**
 * Page object model for TMAG Billing Information page.
 * @author Prince
 *
 */
public class TmagBillingInformation extends TmagServiceSetup {
	
	/**
	 * Enroll in auto-pay check box.
	 */
	@FindBy(css = "#billPayPreferenceAutoPay")
	private WebElement chkbxEnrollAutoPay;

	/**
	 * Save payment method check box.
	 */
	@FindBy(css = "#billPayPreferenceSavePaymentMethod")
	private WebElement chkbxSavePaymentMethod;
	
	/**
	 * Continue to Summary button.
	 */
	@FindBy(css = "#nextButton")
	private WebElement btnContinueToSummary;
	
	public TmagBillingInformation(WebDriver driver) {
		super(driver);
	}
	

}
