package com.tmo.tmag.prepaid.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;

public class TmagLoginPage extends BasePage {
	
	protected String env = System.getProperty("testEnv");
	
	@FindBy(css = ".pageLogo")
	private WebElement pageLogo;
	
	@FindBy(css = "#username")
	private WebElement username;
	
	@FindBy(css = "#password")
	private WebElement password;
	
	@FindBy(css = "#loginButton")
	private WebElement loginBtn;
	
	@FindBy(css = ".modalDialogButton")
	private WebElement passwordDailog;

	public TmagLoginPage(WebDriver driver) {
		super(driver);
	}
	
	public TmagLoginPage openTmag(String url) {
		try{
			log("TMAG URL opening navigation started");
			getDriver().get(url);
		}catch (Exception e) {
			log("TMAG URL opening navigation failed");
			MatcherAssert.assertThat("TMAG URL opening navigation failed.", false);
		}
		return this;
	}
	
	public TmagLoginPage navigateToTMag(){
		try{
			log("TMAG URL opening navigation started");
			navigateTo(Properties.getURLProperty(System.getProperty("testEnv")+".app.TMAG.url"));
			verifyCertificate();
		}catch (Exception e) {
			log("TMAG URL opening navigation failed");
			MatcherAssert.assertThat("TMAG URL opening navigation failed.", false);
		}
		return this;
	}
	
	public TmagHomePagePrepaid doLogin(String usertype) {
		try{
			log("TMAG login using credentials started");
			waitFor(pageLogo, 30);
			setValue(username, Properties.getCredentialsProperty("tmag." + usertype.toLowerCase() + ".username"));
			setValue(password, Properties.getCredentialsProperty("tmag." + usertype.toLowerCase() + ".password"));
			setMacIDCookie("00059a3c7800",getDriver());
			click(loginBtn);
		}catch (Exception e) {
			log("TMAG login using credentials failed");
			MatcherAssert.assertThat("TMAG login using credentials failed.", false);
		}
		return get(TmagHomePagePrepaid.class);
	}
}