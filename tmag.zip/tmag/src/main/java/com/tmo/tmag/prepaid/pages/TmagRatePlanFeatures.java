package com.tmo.tmag.prepaid.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.pages.tmag.TmagWifiCallingPage;
import com.tmo.tmag.data.DatabaseManager;

public class TmagRatePlanFeatures extends TmagCustomerInformationPage {

	@FindBy(css = "frame[name='middle']")
	private WebElement framemiddle;

	@FindBy(css = "input[name='sim'][type='text']")
	private WebElement txtSIM;

	@FindBy(css = "input[name='imei'][type='text']")
	private WebElement txtIMEI;

	@FindBy(css = "#validateButton")
	private WebElement btnValidate;

	@FindBy(css = "#PAY_GO")
	private WebElement payGo;

	public TmagRatePlanFeatures(WebDriver driver) {
		super(driver);
	}

	public TmagRatePlanFeatures ratePlanFeatures() {

		String imei = "";
		try {
			getDriver().getWindowHandles().size();
			getDriver().switchTo().defaultContent();
			switchFrame(framemiddle);
			DatabaseManager db = new DatabaseManager();
			String strSim = db.getSimUpdateStatus(1, System.getProperty("testEnv"));
			try {
				waitFor(txtSIM);
				txtSIM.clear();
				txtSIM.sendKeys(strSim);
			} catch (Exception e) {
				MatcherAssert.assertThat("Rate Plan & Device: Enter SIM", false);
				throw new RuntimeException(e);
			}
			String imeiScript = "function imei_gen() {" + "var pos;"
					+ "var str = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);" + "var sum = 0;"
					+ "var final_digit = 0;" + "var t = 0;" + "var len_offset = 0;" + "var len = 15;" + "var issuer;" + ""
					+ "var rbi = [\"01\",\"10\",\"30\",\"33\",\"35\",\"44\",\"45\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"86\",\"91\",\"98\",\"99\"];"
					+ "var arr = rbi[Math.floor(Math.random() * rbi.length)].split(\"\");" + "str[0] = Number(arr[0]);"
					+ "str[1] = Number(arr[1]);" + "pos = 2;" + "while (pos < len - 1) {"
					+ "str[pos++] = Math.floor(Math.random() * 10) % 10;" + "}" + "" + "len_offset = (len + 1) % 2;"
					+ "for (pos = 0; pos < len - 1; pos++) {" + "if ((pos + len_offset) % 2) {" + "t = str[pos] * 2;"
					+ "if (t > 9) {" + "t -= 9;" + "}" + "sum += t;" + "}" + " else {" + "sum += str[pos];" + "}" + "}" + ""
					+ "final_digit = (10 - (sum % 10)) % 10;" + "str[len - 1] = final_digit;" + "t = str.join('');"
					+ "t = t.substr(0, len);" + "return t;" + "		}; return imei_gen();";
			imei = (String) ((JavascriptExecutor) getDriver()).executeScript(imeiScript);
			waitFor(txtIMEI);
			txtIMEI.clear();
			txtIMEI.sendKeys(imei);
			waitAndClick(btnValidate, 60);

			if (isAlertPresent()) {
				getDriver().switchTo().alert().accept();
			}
			
			log("Btn Validate: Click");
		} catch (Exception e) {
			MatcherAssert.assertThat("Rate Plan Featres Next Button: Click", false);
			close();
			throw new RuntimeException(e);
		}

		return this;
	}
	
	public TmagWifiCallingPage payAsYouGo(String paygooption){
		waitFor(payGo);
		payGo.click();
		log("Clicked on "+paygooption);
		getDriver().switchTo().defaultContent();
		nextButtonClk();
		return get(TmagWifiCallingPage.class);
	}
}
