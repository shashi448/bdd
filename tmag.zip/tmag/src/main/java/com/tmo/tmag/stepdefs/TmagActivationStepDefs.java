package com.tmo.tmag.stepdefs;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tmo.data.ALMData;
import com.tmo.system.LoginSystem;
import com.tmo.tmag.system.ActivationSystem;
import com.tmobile.eqm.testfrwk.ui.core.cucumber.BaseStepDefs;
import com.tmobile.eqm.testfrwk.ui.core.cucumber.CucumberTest;
import com.tmobile.eqm.testfrwk.ui.core.httpclient.TEPService;
import com.tmobile.eqm.testfrwk.ui.core.httpclient.TestDataService;

import cucumber.api.Scenario;

/**
 * Created by Rajesh Ravi on 07/20/2017.
 */

public class TmagActivationStepDefs extends BaseStepDefs {
	private final Logger log = LoggerFactory.getLogger(TmagActivationStepDefs.class);
	private LoginSystem loginSystem;
	private ActivationSystem activationSystem;
	private ALMData almData;
	private long startTime;
	private long endTime;
	private HashMap<Object, Object> testData = new HashMap<>();

	public TmagActivationStepDefs(CucumberTest test) {
		super(test);

		// Common step
		Given("^User is provided with test id \"([^\"]*)\"$", (String arg1) -> {
		});
		// Costco test
		Given("^authorised \"([^\"]*)\"$", (String arg1) -> {
			activationSystem = new ActivationSystem(getDriver());
			activationSystem.tmagLogin(arg1);
		});
		// Prepaid test
		Given("^an authorized user \"([^\"]*)\"$", (String arg1) -> {
			activationSystem = new ActivationSystem(getDriver());
			loginSystem = new LoginSystem(getDriver());
			loginSystem.posLogin(arg1);
			loginSystem.tmagLoginAndPrepaid(arg1);
			loginSystem.storeOpenandTillOpen();
		});
		// Postpaid test
		Given("^an authorised \"([^\"]*)\"$", (String arg1) -> {
			activationSystem = new ActivationSystem(getDriver());
			activationSystem.posLoginAndSetStore();
			activationSystem.tmagLogin(arg1);
		});
		// Costco test
		When("^Credit check with \"([^\"]*)\" is successful$",
				(String arg1) -> activationSystem.personalAccoutCreditCheck((String) testData.get("SSN")));
		When("^Customer wants to activate \"([^\"]*)\" Voice lines and \"([^\"]*)\" Data lines$",
				(Integer arg1, Integer arg2) -> activationSystem.linesToActivate());
		When("^Customer wants \"([^\"]*)\" Rate Plan Type$", (String arg1) -> {
		});
		When("^Customer want \"([^\"]*)\" Device Pricing option$", (String arg1) -> {
			activationSystem.selectPricingOption(arg1);
			activationSystem.enterDeviceDetails((String) testData.get("SIM"));
		});
		When("^Customer want \"([^\"]*)\" type of Protection for Equipment$",
				(String arg1) -> activationSystem.acceptProtectionAndContinue());
		When("^Customer Chooses required \"([^\"]*)\" Emergency support$",
				(String arg1) -> activationSystem.e911Disclaimer());
		When("^Customer provide \"([^\"]*)\" Code for line setup Service, Agreement Preferences, Bill Pay Preferences$",
				(String arg1) -> activationSystem.chooseAreaCodeCostco(arg1));
		Then("^Account successfully activated with BAN and MSISDN$", () -> activationSystem.finishActivation());

		// Prepaid test
		When("^Customers Information  \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" is successful$",
				(String args1, String args2, String args3) -> loginSystem.customerInformation(args1, args2, args3));
		When("^Customer Provides SIM and IMEI$", () -> loginSystem.simandimeiInformation());
		When("^Customers wants \"([^\"]*)\" Rate Plan Type$", (String arg1) -> loginSystem.payasyouGo(arg1));
		When("^Customer wants \"([^\"]*)\" Service$", (String arg1) -> loginSystem.prepaidselectionService(arg1));
		When("^Customer provides \"([^\"]*)\" Code for line setup Service$",
				(String arg1) -> loginSystem.areaCode(arg1));
		When("^Customer wants \"([^\"]*)\" for communication$", (String arg1) -> loginSystem.langSelection(arg1));
		When("^Customers provides \"([^\"]*)\" of Payment to Store rep like Cash DebitCard CreditCard Check$",
				(String tendermethod) -> loginSystem.selectTenderType(tendermethod));
		When("^Customers provides greater than or equal to Balance and completes activation$",
				() -> loginSystem.amountValueSelection());
		Then("^Account is successfully activated with Prepaid MSISDN$", () -> {
		});
		// Postpaid test
		When("^Customer wants to activate single (\\d+) Voice line$",
				(Integer arg1) -> activationSystem.linesToActivate());
		When("^Customer wants \"([^\"]*)\" Device Pricing option$",
				(String arg1) -> activationSystem.selectPricingOption(arg1));
		When("^Customer provides IMEI,SIM and SKU and continues to features$",
				() -> activationSystem.enterDeviceDetails((String) testData.get("SIM")));
		When("^Customer wants \"([^\"]*)\" type of Protection for Equipment$",
				(String arg1) -> activationSystem.declineProtectionAndContinue());
		When("^Customer provides \"([^\"]*)\" Code for line setup Service, Agreement Preferences, Bill Pay Preferences$",
				(String arg1) -> activationSystem.chooseAreaCode(arg1));
		When("^Customer wants to pay \"([^\"]*)\" Additional Down Payment$",
				(String arg1) -> activationSystem.addDownPayment(arg1));
		When("^Customer provides \"([^\"]*)\" of Payment to Store rep like Cash DebitCard CreditCard Check$",
				(String arg1) -> activationSystem.selectTenderType());
		When("^Customer provides \"([^\"]*)\" greater than or equal to Balance and completes activation$",
				(String arg1) -> activationSystem.addPaymentTender());
		Then("^Account is successfully activated with BAN and MSISDN$",
				() -> activationSystem.finishPostpaidActivation());
	}

	private void setTestData(Scenario scenario) {
		JSONObject myJsonObject;
		try {
			myJsonObject = new JSONObject(new JSONTokener(new FileReader(new File("${JSON_FilePath}"))));
			JSONArray myJsonArray = (JSONArray) myJsonObject.get("testCases");
			for (int i = 0; i < myJsonArray.length(); i++) {
				JSONObject myJObject = myJsonArray.getJSONObject(i);
				log.info("Scenario ID: " + scenario.getId());
				String scenarioName = myJObject.get("scenario").toString();
				log.info("Scenario key set are: " + myJObject.keySet());
				if (scenarioName.equalsIgnoreCase(scenario.getName()) && myJObject.keySet().contains("example")
						&& scenario.getId()
								.endsWith(String.valueOf(Integer.parseInt((String) myJObject.get("example")) + 1))) {
					loadData(myJObject, scenario);
					break;
				} else if (scenarioName.equalsIgnoreCase(scenario.getName())
						&& !(myJObject.keySet().contains("example"))) {
					loadData(myJObject, scenario);
					break;
				}
			}
			setTDAPIData();

		} catch (Exception e) {
			log.info(e.getMessage() + e);
		}
	}

	private void setTDAPIData() {
		try {
			if (testData.get("SIM").toString().isEmpty() || testData.get("SIM").toString() == null) {
				TestDataService service = new TestDataService();
				testData.replace("SIM", service.getSim(System.getProperty("testEnv"), "AA").getSim());
				log.info("Service call for SIM executed");
				log.info("SIM from service" + testData.get("SIM").toString());
			}

			if (testData.get("SSN").toString().isEmpty() || testData.get("SSN").toString() == null) {
				TestDataService service = new TestDataService();
				java.util.Map<String, String> SSNVal = service.getScenario(System.getProperty("testEnv"),
						"customer_ssn");
				testData.replace("SSN", SSNVal.get("SSN"));
				log.info("Service call for SSN executed");
				log.info("SSN from service" + testData.get("SSN").toString());
			}

		} catch (Exception e) {
			log.info(e.getMessage() + e);
		}
	}

	private void loadData(JSONObject myJObject, Scenario scenario) {
		for (int j = 0; j < myJObject.length(); j++) {
			testData.put(myJObject.keySet().toArray()[j], myJObject.get((String) myJObject.keySet().toArray()[j]));
		}
		testData.remove(scenario);
	}

	@cucumber.api.java.Before
	public void beforeScenario(Scenario scenario) {
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/drivers/chromedriver.exe");
		System.setProperty("webdriver.ie.driver", "./src/test/resources/drivers/IEDriverServer.exe");
		System.setProperty("webfriver.firefox.driver", "./src/test/resources/drivers/geckodriver.exe");
		startTime = System.currentTimeMillis();
		almData = new ALMData();
		initSceanario(scenario);
		setTestData(scenario);
	}

	@cucumber.api.java.After
	public void afterScenario(Scenario scenario) {
		long endTime = System.currentTimeMillis();
		int totalTime = ((int) endTime - (int) startTime) / 1000;
		almData.setTestDuration(Long.toString(totalTime));
		if (scenario.getStatus().contains("passed"))
			almData.setTestExecutionResult("Passed");
		else
			almData.setTestExecutionResult("Failed");
		TEPService alm = new TEPService();
		alm.createAlmUpdate(almData.getDomain(), almData.getProject(), almData.getTestId(), almData.getTestSetId(),
				almData.getTestExecutionResult(), almData.getTestDuration());
		endScenario(scenario);
	}
}