package com.tmo.tmag.pages;

import javax.management.RuntimeErrorException;
import java.util.concurrent.TimeUnit;
import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.hamcrest.MatcherAssert;
//import com.sun.org.apache.bcel.internal.generic.Select;
import com.tmo.tmag.base.BasePage;

/**
 * Page object model for TMAG Service Setup Page.
 * @author Rajesh & Prince
 *
 */

public class TmagServiceSetup extends BasePage {

	@FindBy(css = "#acceptDisclaimerRead")
	private WebElement chkbxAcceptE911Disclaimer;
	
	@FindBy(css = "#npanxxSelected")
	private WebElement drpdwnAreaCode;
	
	@FindBy(css="input[id='nextButton'][class='primaryButton']")
	private WebElement btnContinueToBillingInfo;
	
	@FindBy(css="input[name='kittype'][value='Y']")
	private WebElement radioInstore;

	@FindBy(css="input[name='kittype'][value='N']")
	private WebElement radioPrePurchased;

	@FindBy(css="frame[name='middle']")
	private WebElement framemiddle;

	@FindBy(css="#cityCodeNpa")
	private WebElement areaCode;

	@FindBy(css="input[name='language'][value='E']")
	private WebElement radioEnglish;

	@FindBy(css="input[name='language'][value='S']")
	private WebElement radioSpanish;

	@FindBy(css="#epin")
	private WebElement ddlEpin; 

	@FindBy(css="input[id='epinNow'][name='epinReedem']")
	private WebElement radioNowRedeem;

	@FindBy(css="input[id='epinLater'][name='epinReedem']")
	private WebElement radioLaterRedeem;

	@FindBy(css="#couponPrePurchased0")
	private WebElement couponsPrePurchased;

	@FindBy(css="#couponInStore0")
	private WebElement couponsInstore;

	@FindBy(css="input[name='couponSku0'][type='text']")
	private WebElement prepaidCouponsSKU;

	@FindBy(css="frame[name='prepaidnav']")
	private WebElement frameprenav;

	@FindBy(css="input[name='nextButton']")
	private WebElement btnNext;

	public TmagServiceSetup(WebDriver driver) {
		super(driver);
	}

	public TmagServiceSetup prepaidHandsetSel() {
		try{
			getDriver().switchTo().defaultContent();
			switchFrame(framemiddle);
			waitAndClick(radioPrePurchased,30);
			log("Selected Handset: Pre-Purchased ");
			AreaCode("");
			prepaidRedeem();
			prepaidCoupons();
			if(isAlertPresent()){
				getDriver().switchTo().alert().accept();
			}				
			getDriver().switchTo().defaultContent();
			log("Clicked on Next button to toggle to POS");
			continueToPos();
			log("Prepaid Service Next Button" + ": Click");
			verifyCertificate();
			setMacIDCookie("00059a3c7800", getDriver());
		}catch (Exception e) {
			log.info("Prepaid Service Next Button: Click failed");
			MatcherAssert.assertThat("Prepaid Service Next Button: Click", false);
			close();
			throw new RuntimeException(e);
		}
		return this;
	}

	public TmagServiceSetup prepaidServiceSelection(String prepaidSelection){
		try{
			getDriver().switchTo().defaultContent();
			switchFrame(framemiddle);
				waitAndClick(radioPrePurchased,30);
			log("Selected Handset: Pre-Purchased "+prepaidSelection);
		}
		catch (Exception e) {
			log.info("Prepaid selection Button: Click failed");
			MatcherAssert.assertThat("Prepaid selection Button: Click", false);
			throw new RuntimeException(e);
		}
		return this;
	}

	public TmagServiceSetup AreaCode(String areaCodeValue) {
		try {
			waitFor(areaCode);
			Select npaDropdown = new Select(areaCode);
			areaCode.sendKeys(areaCodeValue.substring(0, 6));
			log("MSISDN selected for NPA:".substring(0, 6));
		} catch (Exception e) {
			log.info("Service Setup: Select Area Code failed");
			MatcherAssert.assertThat("Service Setup: Select Area Code", false);
			new RuntimeException(e);
		}
		return this;
	}
	public TmagServiceSetup languageSel(String language) {
		try{
			if(radioEnglish.getText().contains(language))
				waitAndClick(radioEnglish, 60);
		}catch (Exception e) {
			log.info("Service Setup: Select language failed");
			MatcherAssert.assertThat(radioEnglish+" Btn is not available", false);
			new RuntimeException(e);
		}
		return this;
	}

	public TmagServiceSetup prepaidHandsetSelection(){
		try{
			prepaidRedeem();
			prepaidCoupons();
			if(isAlertPresent()){
				getDriver().switchTo().alert().accept();
			}				
			getDriver().switchTo().defaultContent();
			log("Clicked on Next button to toggle to POS");
			continueToPos();
			log("Prepaid Service Next Button" + ": Click");
			verifyCertificate();
			setMacIDCookie("00059a3c7800", getDriver());	
		}
		catch (Exception e) {
			MatcherAssert.assertThat("Prepaid Serivce Next Button: Click", false);
			close();
			throw new RuntimeException(e);
		}
		return this;
	}
	public void prepaidEpin() {
		if ("EPIN"!=null) {
			waitFor(ddlEpin);
			Select epin = new Select(ddlEpin);
			epin.selectByVisibleText("EPIN100");
		}
		log("Selected EPIN: EPIN100");
	}

	public void prepaidRedeem() {
		String Redeem = "Later";
		if(Redeem.toUpperCase().equals("NOW")) {
			waitAndClick(radioNowRedeem,60);
		} else if (Redeem.toUpperCase().equals("LATER")) {
			waitAndClick(radioLaterRedeem, 60);
		}
		log("Redeem Selected: "+Redeem);
	}

	public void prepaidCoupons() {
		waitAndClick(couponsPrePurchased, 30);
		log("Coupons Selected: ");
	}
	
	public TmagServiceSetup acceptDisclaimer() {
		verifyPageLoad("TMAG Service Setup");
		click(chkbxAcceptE911Disclaimer);
		return this;
	}
	
	public TmagServiceSetup selectAreaCode(String areaCodeValue) {
		waitFor(drpdwnAreaCode, 10);
		setValue(drpdwnAreaCode, areaCodeValue);
		return this;
	}
	
	public TmagServiceSetup continueToBillingInfo() {
		waitAndClick(btnContinueToBillingInfo,30);
		return this;
	}
	
	public TmagServiceSetup selectServiceSetup() {
		try {
			acceptDisclaimer();
			selectAreaCode(null);
			continueToBillingInfo();
		} catch (Exception e) {
			log("Error in select Service Setup"+e.getMessage());
			MatcherAssert.assertThat("Error in select Service Setup", false);
		}
		return this;
	}
	
	public void continueToPos() {
		switchFrame(frameprenav);
		waitAndClick(btnNext, 10);
		try {
			if(isAlertPresent()){
				getDriver().switchTo().alert().accept();
			}			
			try {
				new WebDriverWait(getDriver(), 10).until(ExpectedConditions.alertIsPresent());
				getDriver().switchTo().alert().accept();
			} catch (Exception e) {
				getDriver().findElement(By.tagName("body")).click();
				getDriver().findElement(By.tagName("body")).sendKeys(Keys.ENTER);
			}

		} catch (UnhandledAlertException e) {
			log("Inside 1st Catch");
			log("Pressed Enter");
			if(isAlertPresent()){
				getDriver().switchTo().alert().accept();
			}	
		}
		getDriver().switchTo().defaultContent();
	}
}
