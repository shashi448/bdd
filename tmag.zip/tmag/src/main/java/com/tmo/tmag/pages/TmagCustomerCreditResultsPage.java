package com.tmo.tmag.pages;

import org.codehaus.groovy.ast.tools.GeneralUtils;
import org.glassfish.hk2.utilities.general.GeneralUtilities;
import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * TMAG Customer Credit Results Page Model.
 * @author Rajesh Ravi
 *
 */
public class TmagCustomerCreditResultsPage extends TmagCustomerCreditEntryPage {
	
	/**
	 * Continue to Rate Plan and Device button.
	 */
	@FindBy(css = "#nextButton")
	private WebElement btnContinueToRatePlanAndDevice;

	public TmagCustomerCreditResultsPage(WebDriver driver) {
		super(driver);
	}
	
	public void continueToNextPage() {
		try{
			verifyPageLoad("TMAG Credit Check Results");
			waitAndClick(btnContinueToRatePlanAndDevice, 120);
			log("TMAG Credit check is successfull");
		}catch (Exception e) {
		 log("TMAG Credit check failed. TMAG continue to rate plan and device button is not enabled.");
		 MatcherAssert.assertThat("TMAG Credit check failed and TMAG continue to rate plan and device button is not enabled.", false);
		}
	}
	}