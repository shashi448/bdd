package com.tmo.tmag.pages;

import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.property.GetProperty;
import org.codehaus.groovy.ast.tools.GeneralUtils;
import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.Properties;
import com.tmobile.apptests.common.general.CommonUtils;
import com.tmobile.apptests.common.utils.DatabaseManager;
import com.tmobile.apptests.common.utils.ImeiGenerator;

/**
 * Page object model for TMAG Rate Plan and Device Selection Page.
 * 
 * @author Prince
 *
 */
public class TmagRatePlanAndDeviceSelectionPage extends TmagCustomerCreditResultsPage {

	@FindBy(css = "#planType")
	private WebElement drpdwnPricingOptions;

	@FindBy(css = "#imei")
	private WebElement txtFieldImei;

	@FindBy(css = "#sim")
	private WebElement txtFieldSim;

	@FindBy(css = "#sku")
	private WebElement txtFieldSku;

	@FindBy(css = "#validateButton")
	private WebElement btnValidateDevice;

	@FindBy(css = "#nextButton")
	private WebElement btnContinueToFeatures;
	
	@FindBy(id="markets")
	private WebElement cmbMarkets;

	public TmagRatePlanAndDeviceSelectionPage(WebDriver driver) {
		super(driver);
	}
	
	private TmagRatePlanAndDeviceSelectionPage isRatePlanDeviceSelectionPage() {
		verifyPageLoad("TMAG Rate Plan and Device Selection");
		return this;
	}

	public TmagRatePlanAndDeviceSelectionPage selectPricingOptions(String arg1) {
		CommonUtils.sleep(5, TimeUnit.SECONDS);  /*This is needed to support variant page load issue*/
		isRatePlanDeviceSelectionPage(); 
		setValue(drpdwnPricingOptions, arg1);
		log("Success: EIP Pricing option chosen.");
		return this;
	}
	
	private static String generateImei(String tac, int imeiLength) {
		int[] digits = new int[imeiLength];
		Boolean isUnique = true;
		String tempImei = "";
		int randNumStart = 0;

		if (tac != null) {
			randNumStart = 8;
			String[] tacString = tac.split("");
			for (int i = 0; i < tacString.length; i++) {
				digits[i] = Integer.parseInt(tacString[i]);
			}
		}
		while (isUnique) {
			for (int j = 0; j < imeiLength - 1; j++) {
				if (j >= randNumStart) {
					digits[j] = (int) Math.round(Math.random() * 9);
				}
			}

			int sum = 0;
			Boolean alt = true;
			for (int k = imeiLength - 2; k >= 0; k--) {
				if (alt) {
					int temp = digits[k];
					temp *= 2;
					if (temp > 9) {
						temp -= 9;
					}
					sum += temp;

				} else {
					sum += digits[k];
				}
				alt = !alt;
			}
			int modulo = sum % 10;
			if (modulo > 0) {
				digits[imeiLength - 1] = 10 - modulo;
			}
			for (int m = 0; m < digits.length; m++) {
				tempImei += digits[m];
			}

			if (tempImei.length() != 15) {
				isUnique = false;
			} else {
				isUnique = false;
				return tempImei;
			}

		}

		return null;
	}
	
	private static String getIMEI(String tac) {
		return generateImei(tac, 15);
	} 
	
/*	private String getIMEI(String tac) {
		return getIMEINumber();
	} */

	private String retrieveAvailableSim() {
		String resultSim;
		try
		{
		resultSim = getSim(System.getProperty("testEnv"));
		} catch (Exception e) {
			resultSim = "";
		}
	if (resultSim.isEmpty()) {
			DatabaseManager db = new DatabaseManager();
			resultSim = db.getSimNumber(System.getProperty("testEnv"), 5);
		}
	if (resultSim.isEmpty()) {
			log("Sim Retrieval Failed.");
			assertMatcher("Sim Retrieval from DB and TDM API failed.", false);
		}
		log("SIM: " + resultSim);
		return resultSim;
	}

	public TmagRatePlanAndDeviceSelectionPage enterImei() {
		setValue(txtFieldImei, getIMEI("35206106"));
		return this;
	}

	public TmagRatePlanAndDeviceSelectionPage enterSim(String sim) {
		if (sim.isEmpty()) {
			sim = retrieveAvailableSim();
		}
		setValue(txtFieldSim, sim);
		return this;
	}

	public TmagRatePlanAndDeviceSelectionPage enterSku() {
		setValue(txtFieldSku, Properties.getUserProperty("sku"));
		return this;
	}

	public TmagRatePlanAndDeviceSelectionPage validateDevice() {
		click(btnValidateDevice);
		return this;
	}

	public TmagRatePlanAndDeviceSelectionPage continueToFeatures() {
		click(btnContinueToFeatures);
		return this;
	}
	
	public TmagRatePlanAndDeviceSelectionPage selectRatePlanAndDevice(String pricing,String sim) {
		try{
	       	if(isElementPresent(drpdwnPricingOptions)){
	    		selectPricingOptions(pricing);
	    	}
	    	log("Pricing option selection pass");
	    	enterImei();
	    	enterSim(sim);
	    	enterSku();
	    	validateDevice();
	    	continueToFeatures();
	    }
	    catch(Exception e)
		{
	    	log("Error in Pricing option selection");
	    	MatcherAssert.assertThat("Pricing option selection fail", true);
		}
		return this;
	}
}
