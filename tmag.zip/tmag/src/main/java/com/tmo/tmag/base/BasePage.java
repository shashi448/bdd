package com.tmo.tmag.base;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Set;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tmo.tmag.base.Constants;
import com.tmobile.eqm.testfrwk.ui.core.httpclient.TestDataService;
import com.tmobile.eqm.testfrwk.ui.core.web.WebPage;

public class BasePage extends WebPage {

	public final Logger log = LoggerFactory.getLogger(BasePage.class);

	protected WebDriver driver;

	public BasePage(WebDriver webDriver) {
		super(webDriver);
		this.driver = webDriver;
	}

	protected void jsClick(WebElement ele) {
		waitFor(ele, 60);
		JavascriptExecutor executor = (JavascriptExecutor) getDriver();
		executor.executeScript("arguments[0].click();", ele);
		log("Click performed on element: " + ele);
	}
	
	public void click(WebElement ele) {
		waitFor(ele, 30);
		ele.click();
		log("Click performed on element: " + ele);
	}

	public void waitAndClick(WebElement ele, int time) {
		try {
			waitForClick(ele, time);
			ele.click();
		} catch (UnhandledAlertException e) {
			acceptAlert();
			log.info("Exception occured in click: " + e);
		}}

	public void setValue(WebElement ele, String str) {
		waitFor(ele, 30);
		ele.sendKeys(str);
		ele.sendKeys(Keys.TAB);
		log("Value: " + str + " is set to element: " + ele);
	}
	
	public void selectByText(WebElement ele, String str) {
		WebElement element = ele;
		waitFor(ele, 30);
		Select select = new Select(ele);
		select.selectByVisibleText(str);
	}
	
	public void selectByIndex(WebElement ele, int index){
		waitFor(ele, 30);
		Select select = new Select(ele);
		select.selectByIndex(index);
	}

	public void log(String str) {
		log.info(str);
	}

	protected void waitFor(WebElement ele) {
		waitForPageToLoad();
		log("Waiting 60 seconds for element: " + ele + " to be visible.");
		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {
			log.info("Exception in wait for visible: " + e);
			MatcherAssert.assertThat(ele + " is not visible within 60 seconds.", false);
		}}

	protected void waitFor(WebElement ele, int time) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, time).until(ExpectedConditions.visibilityOf(ele));
		} catch (Exception e) {
			log.info("Exception in wait for visible: " + e);
			MatcherAssert.assertThat(ele + " is not visible within " + time + " seconds. " + e.getMessage(), false);
		}}

	protected void waitForClick(WebElement ele, int time) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, time).until(ExpectedConditions.elementToBeClickable(ele));
		} catch (Exception e) {
			log.info("Exception in wait for clickable: " + e);
			MatcherAssert.assertThat(ele + " is not clickable within " + time + " seconds.", false);
		}}

	protected void waitForClick(WebElement ele) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(ele));
		} catch (Exception e) {
			log.info("Exception in wait for clickable: " + e);
			MatcherAssert.assertThat(ele + " is not clickable within 60 seconds.", false);
		}}

	protected void waitForPage() {
		try {
			new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
					.executeScript("return document.readyState").equals(Constants.complete.toString()));
		} catch (Exception e) {
			isAlertPresent();
			log.info("Wait for page to load failed with exception: " + e);
		}}
	
	public boolean isAlertPresent() {
		boolean foundAlert = false;
		WebDriverWait wait = new WebDriverWait(getDriver(), 10);
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			foundAlert = true;
		} catch (TimeoutException e) {
			log.info("Alert not present: " + e);
		}
		return foundAlert;
	}

	public boolean verifyWindowPresenceByURL(String urlToSwitch) {
		try {
			waitFor(ExpectedConditions.numberOfWindowsToBe(2), 5);
		} catch (Exception e) {
			
		}
		Set<String> allWindows = getDriver().getWindowHandles();
		boolean windowexist = false;
		for (String currentWindow : allWindows) {
			if (getDriver().switchTo().window(currentWindow).getCurrentUrl().contains(urlToSwitch)) {
				getDriver().switchTo().window(currentWindow);
				windowexist = true;
				return true;
			}
		}
		return windowexist;
	}

	public void switchToWindowByURL(String urlToSwitch) {
		Set<String> allWindows = getDriver().getWindowHandles();
		for (String currentWindow : allWindows) {
			if (getDriver().switchTo().window(currentWindow).getCurrentUrl().contains(urlToSwitch)) {
				getDriver().switchTo().window(currentWindow);
				return;
			}
		}
	}

	public void verifyCertificate() {
		if (driver.getTitle().equalsIgnoreCase("Certificate Error: Navigation Blocked"))
			waitAndClick(driver.findElement(By.cssSelector("#overridelink")), 20);
	}

	public void navigateTo(String url) {
		driver.navigate().to(url);
	}

	public void switchToParentWindow() {
		getDriver().switchTo().window((String) getDriver().getWindowHandles().toArray()[0]);
	}
	
	public void switchToParentWindowAndCloseChild() {
		getDriver().switchTo().window((String) getDriver().getWindowHandles().toArray()[0]);
	}
	
	public void switchToSecondWindow() {
		waitFor(ExpectedConditions.numberOfWindowsToBe(2), 30);
		Object window1 = getDriver().getWindowHandles().toArray()[1];
		getDriver().switchTo().window((String) window1);
	}
	
	public void switchToSecondWindow(int time) {
		waitFor(ExpectedConditions.numberOfWindowsToBe(2), time);
		Object window1 = getDriver().getWindowHandles().toArray()[1];
		getDriver().switchTo().window((String) window1);
	}

	public BasePage updateURL() {
		verifyCertificate();
		String url = getDriver().getCurrentUrl();
		if (!url.contains("qatwswatx532.gsm1900.org")) {
			url = url.replace("qatwswatx532", "qatwswatx532.gsm1900.org");
			getDriver().get(url);
		}
		if (!url.contains("qatwswatx522.gsm1900.org")) {
			url = url.replace("qatwswatx522", "qatwswatx522.gsm1900.org");
			getDriver().get(url);
		}
		if (!url.contains("qatwswatx162.gsm1900.org")) {
			url = url.replace("qatwswatx162", "qatwswatx162.gsm1900.org");
			getDriver().get(url);
		}
		return this;
	}

	public void setMacIDCookie(String macID, WebDriver driver) {
		Cookie ck = new Cookie("MacId", macID); // 00059a3c7800
		driver.manage().addCookie(ck);
		ck = new Cookie("NetID", macID); // 00059a3c7800
		driver.manage().addCookie(ck);
	}

	public void switchFrame(WebElement ele) {
		try {
			driver.switchTo().defaultContent();
			waitFor(ele);
			driver.switchTo().frame(ele);
		} catch (ElementNotVisibleException e) {
			MatcherAssert.assertThat(ele + " is not visible within 60 seconds.", false);
			throw new RuntimeException(e);
		}
	}

	public void switchFrameInFrame(WebElement frame, WebElement frame2) {
		try {
			driver.switchTo().defaultContent();
			waitFor(frame);
			driver.switchTo().frame(frame).switchTo().frame(frame2);
			log("Switched to " +  frame.toString() + " then " + frame2.toString() + " successfully.");
		} catch (ElementNotVisibleException e) {
			MatcherAssert.assertThat(frame + " is not visible within 60 seconds.", false);
			throw new RuntimeException(e);
		}
	}

	public void switchToDefault() {
		driver.switchTo().defaultContent();
	}

	public void acceptAlert() {
		try {
			if (isAlertPresent()) {
				driver.switchTo().alert().accept();
				driver.switchTo().defaultContent();
				waitForPageToLoad();
			}
		} catch (Exception e) {
			log.info("Exception occured in alert handling." + e);
		}
	}

	public void dismissAlert() {
		if (isAlertPresent()) {
			driver.switchTo().alert().dismiss();
			driver.switchTo().defaultContent();
			waitForPageToLoad();
		}
	}

	public boolean isElementPresent(WebElement ele) {
		boolean flag = false;
		try {
			if (ele.isDisplayed())
				flag = true;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return flag;
	}

	public void close() {
		getDriver().close();
	}

	public String getSim(String env) {
		TestDataService service = new TestDataService();
		return service.getSim(env, "").getSim();
	}
	
	protected String getIMEINumber() {
		String imeiScript = "function imei_gen() {" + "var pos;"
				+ "var str = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);" + "var sum = 0;"
				+ "var final_digit = 0;" + "var t = 0;" + "var len_offset = 0;" + "var len = 15;" + "var issuer;" + ""
				+ "var rbi = [\"01\",\"10\",\"30\",\"33\",\"35\",\"44\",\"45\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"86\",\"91\",\"98\",\"99\"];"
				+ "var arr = rbi[Math.floor(Math.random() * rbi.length)].split(\"\");" + "str[0] = Number(arr[0]);"
				+ "str[1] = Number(arr[1]);" + "pos = 2;" + "while (pos < len - 1) {"
				+ "str[pos++] = Math.floor(Math.random() * 10) % 10;" + "}" + "" + "len_offset = (len + 1) % 2;"
				+ "for (pos = 0; pos < len - 1; pos++) {" + "if ((pos + len_offset) % 2) {" + "t = str[pos] * 2;"
				+ "if (t > 9) {" + "t -= 9;" + "}" + "sum += t;" + "}" + " else {" + "sum += str[pos];" + "}" + "}" + ""
				+ "final_digit = (10 - (sum % 10)) % 10;" + "str[len - 1] = final_digit;" + "t = str.join('');"
				+ "t = t.substr(0, len);" + "return t;" + "		}; return imei_gen();";
		return (String) ((JavascriptExecutor) driver).executeScript(imeiScript);
	}
	
	/**
	 * Matcher Assert method simplified.
	 * @param message the message
	 * @param flag pass or failed test case
	 */
	public void assertMatcher(String message, Boolean flag) {
		MatcherAssert.assertThat(message, flag);
	}
	
	/**
	 * Verifies if page loaded successfully.
	 * @param page Name of the page.
	 */
	public void verifyPageLoad(String page) {
		try {
			waitForPageToLoad();
			log(page + " page loaded successfully.");
			assertMatcher(page + " page load successful.", true);
		} catch (Exception e) {
			log(page + " page load failure.");
			assertMatcher(page + " page load failed.", false);
		}
	}
	
	//Check back if required in other steps
/*	protected void waitForPageToLoad() {
		waitForPage();
		try {
			waitFor(ExpectedConditions.invisibilityOfAllElements(driver.findElements(By.cssSelector(".fa-spinner"))));
		} catch (Exception e) {
			log.info("Exception in invisibility of spinner: " + e);
		}
		waitForPage();
	} */ 
	
	protected void waitForPageToLoad() {
	try {
		new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").equals(Constants.complete.toString()));
	} catch (Exception e) {
		isAlertPresent();
		log.info("Wait for page to load failed with exception: " + e);
	}}
	
	protected void setMacIDCookie(WebDriver driver) {
		String mac = getMacID();
		Cookie ck = new Cookie("MacId", mac);
		driver.manage().addCookie(ck);
		ck = new Cookie("NetID", mac);
		driver.manage().addCookie(ck);
	}

	protected String getMacID() {
		String macID = null;
		try {
			InetAddress ip = InetAddress.getLocalHost();
			NetworkInterface network = NetworkInterface.getByInetAddress(ip);
			byte[] mac = network.getHardwareAddress();
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < mac.length; i++) {
				sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
			}
			macID = sb.toString().replace("-", "").toLowerCase();
		} catch (UnknownHostException | SocketException e) {
			log.error(e.getMessage() + e);
		}
		return macID;
	}
}