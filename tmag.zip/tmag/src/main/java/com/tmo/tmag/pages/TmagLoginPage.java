package com.tmo.tmag.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;
import com.tmo.tmag.base.TmagBasePage;

/**
 * Tmag Login Page (Postpaid).
 * @author Prince
 *
 */
public class TmagLoginPage extends BasePage {
	
	@FindBy(css = "#username")
	private WebElement username;

	@FindBy(css = "#password")
	private WebElement password;
	
	@FindBy(css = "#loginButton")
	private WebElement btnLogIn;
	
	@FindBy(css = "#modalDialog")
	private WebElement passwordUpdateReminder;
	
	@FindBy(css = "#0")
	private WebElement btnClose;
	
	@FindBy(css = "#appLinkPersonalAccount")
	private WebElement lnkPersonalAccount;
	
	public TmagLoginPage(WebDriver webDriver) {
		super(webDriver);
	}
	
	private TmagLoginPage enterUsername(String arg1) {
		setValue(username, arg1);
		return this;
	}
	
	private TmagLoginPage enterPassword(String arg1) {
		setValue(password, arg1);
		return this;
	}
	
	/**
	 * Username needs to be passed in order to retrieve password and login.
	 * @param user
	 * @return
	 */
	public TmagLoginPage doTmagLogin(String user) {
		verifyPageLoad("TMAG Login");
		try {
			enterUsername(Properties.getCredentialsProperty("tmag." + user.toLowerCase() + ".username"));
			enterPassword(Properties.getCredentialsProperty("tmag." + user.toLowerCase() + ".password"));
		} catch (Exception e) {
			log("Failed to retrieve login credentials from properties file.");
			assertMatcher("Failed to retrieve login credentials.", false);
		}
		setMacIDCookie("00059a3c7800",getDriver());
		click(btnLogIn);
		return this;
	}
	
	public TmagLoginPage passwordUpdatePopupHandler() {
		if (isElementPresent(passwordUpdateReminder)) {
			click(btnClose);
		}
		return this;
	}
	
	public TmagLoginPage isTmagLoginSuccessful() {
		passwordUpdatePopupHandler();
		if (isElementPresent(lnkPersonalAccount)) {
			MatcherAssert.assertThat("TMAG Login Successful!",true);
		}		
		return this;
	}
}
