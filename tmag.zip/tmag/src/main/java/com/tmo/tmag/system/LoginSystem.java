package com.tmo.tmag.system;

import org.hamcrest.MatcherAssert;
import org.mortbay.log.Log;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.tmo.pages.pos.POSEmailCapturePrepaid;
import com.tmo.pages.pos.PosCustomerInformation;
import com.tmo.pages.pos.PosLoginPage;
import com.tmo.pages.tmag.PrepaidMenuPage;
import com.tmo.pages.tmag.TmagWifiCallingPage;
import com.tmo.tmag.base.BaseSystem;
import com.tmo.tmag.base.LoginPage;
import com.tmo.tmag.base.Properties;
import com.tmo.tmag.pages.TmagServiceSetup;
import com.tmo.tmag.prepaid.pages.TmagCustomerInformationPage;
import com.tmo.tmag.prepaid.pages.TmagHomePagePrepaid;
import com.tmo.tmag.prepaid.pages.TmagLoginPage;
import com.tmo.tmag.prepaid.pages.TmagRatePlanFeatures;

// Removed exceptions based on review comments(08/04) - throw new RuntimeException(e);


public class LoginSystem extends BaseSystem {

	protected String env = System.getProperty("testEnv");
	
	public LoginSystem(WebDriver webDriver) {
		super(webDriver);
	}
	
	public void log(String str) {
		login.log(str);
	}
	
	private LoginPage login;
	private TmagLoginPage tmagLogin;
	private PosLoginPage posLogin;
	private PosCustomerInformation posCustomer;
	private TmagHomePagePrepaid tmagHomePage;
	private TmagCustomerInformationPage tmagCustomerInfo;
	
	public void login() {
		login = new LoginPage(driver);
		login.doLogin();
	}

	public void tmagLogin(String arg1){
		tmagLogin = new TmagLoginPage(driver);
		try{
			Log.info("Tmag login navigation started");
			tmagLogin.navigateToTMag();			
			tmagLogin.doLogin(arg1);			
		}catch (Exception e) {
			Log.info("Tmag login failed");
			MatcherAssert.assertThat(tmagLogin + " is not visible within 60 seconds.", false);
		}
	}

	public void validateStoreAndTill() {
		tmagHomePage = new TmagHomePagePrepaid(driver);
		try{
			tmagHomePage.validateStoreAndTill();
		}
		catch (NoSuchElementException e) {
			Log.info("validateStoreAndTill failed");
			MatcherAssert.assertThat("TMAG Store and till open failed.", false);
		}
	}

	public void posLoginAndSetStore() {
		try{
			Log.info("POS login and store setup started");
			driver.get(Properties.getURLProperty((System.getProperty("testEnv"))+".app.POS.url"));
			posLogin = new PosLoginPage(driver);
			posLogin.doLogin("POS").clickAdmin((Properties.getURLProperty("newStore"))).clickOkPopUp();
		}catch (Exception e) {
			Log.info("POS login and store setup failed");
			MatcherAssert.assertThat("POS login and store setup failed.", false);
		}
	}

	public void posCustomerInformationSteps(){
		posCustomer = new PosCustomerInformation(driver);
		try{
			new POSEmailCapturePrepaid(driver).posValidation();	
		}
		catch (Exception e) {
			Log.info("posCustomerInformationSteps failed");
			MatcherAssert.assertThat("Pos Customer Information Failuer", false);
		}
	}

	public void customerInformation(String args1, String args2, String args3) {
		try{
			tmagCustomerInfo = new TmagCustomerInformationPage(driver);
			tmagCustomerInfo.customerInformation(args1, args2, args3);
		}
		catch (NoSuchElementException e) {
			Log.info("customerInformation failed");
			MatcherAssert.assertThat(" is not visible within 60 seconds.", false);
		}
	}

	public void simandimeiInformation(){
		try{
			new TmagWifiCallingPage(driver).ratePlanFeatures();
		}
		catch (Exception e) {
			Log.info("simandimeiInformation failed");
			MatcherAssert.assertThat("Failed on SIM and IMEI Information Page", false);
		}
	}

	public void payasyouGo(String payasYouGo){
		try{
			new TmagRatePlanFeatures(driver).payAsYouGo(payasYouGo);
			new TmagWifiCallingPage(driver).E911AddressPrepaid();
		}
		catch (Exception e) {
			Log.info("payasyouGo failed");
			MatcherAssert.assertThat("Failed at Pay As You Go", false);
		}
	}

	public void prepaidselectionService(String prepaidSelection){
		try{
			new TmagServiceSetup(driver).prepaidServiceSelection(prepaidSelection);
		}
		catch (Exception e) {
			Log.info("prepaidselectionService failed");
			MatcherAssert.assertThat("Failed at Prepaid Selection Service" + e.getMessage(), false);
		}
	}

	public void areaCode(String areaCode){
		try{
			new TmagServiceSetup(driver).AreaCode(areaCode);
		}catch (Exception e) {
			Log.info("areaCode selection failed");
			MatcherAssert.assertThat("Failed at Area Code Selection Service" + e.getMessage(), false);
		}
	}

	public void langSelection(String language){
		try{
			new TmagServiceSetup(driver).languageSel(language);
			new TmagServiceSetup(driver).prepaidHandsetSelection();
		}catch (Exception e) {
			Log.info("language selection failed");
			MatcherAssert.assertThat("Language  Selection Service" + e.getMessage(), false);
		}
	}

	public void selectTenderType(String tenderType){
		try{
			new PosCustomerInformation(driver).getItemEntry();
			new POSEmailCapturePrepaid(driver).testLease(tenderType);
		}catch (Exception e) {
			Log.info("selectTenderType selection failed");
			MatcherAssert.assertThat("Failed at Tender Type Selection" + e.getMessage(), false);
		}
	}

	public void amountValueSelection(){
		try{			
			new POSEmailCapturePrepaid(driver).posAmountValueSelection();
		}catch (Exception e) {
			Log.info("amountValueSelection selection failed");
			MatcherAssert.assertThat("Failed at Amount Value Selection" + e.getMessage(), false);
		}
	}
	
	public void addTenderAndComplete(){
		try{
			new POSEmailCapturePrepaid(driver).addTender();
		}catch (Exception e) {
			Log.info("addTenderAndComplete selection failed");
			MatcherAssert.assertThat("Failed at Tender" + e.getMessage(), false);
		}
	}
	
	public void storeOpenandTillOpenPrepaid(){
		try{
			new TmagHomePagePrepaid(driver).validateStoreAndTill().
			clickPrepaidMenuLnk().
			updateURL();
			new PrepaidMenuPage(driver).
			clickPrepaidPhone();
		}catch (Exception e) {
			log("storeOpenandTillOpenPrepaid selection failed");
			MatcherAssert.assertThat("Failed to open store and till" + e.getMessage(), false);
		}
	}
	
	public void storeOpenAndTillOpen() {
		new TmagHomePagePrepaid(driver).validateStoreAndTill();
	}
	}