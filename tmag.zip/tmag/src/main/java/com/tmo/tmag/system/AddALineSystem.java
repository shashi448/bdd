package com.tmo.tmag.system;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tmo.pages.base.TmagConstants;
import com.tmo.pages.pos.DeviceTradeInQuoteTool;
import com.tmo.pages.pos.PosAddTenderPage;
import com.tmo.pages.pos.PosCalculatePaymentsPage;
import com.tmo.pages.pos.PosCustomerOverviewPage;
import com.tmo.pages.pos.PosItemEntryPage;
import com.tmo.pages.tmag.TmagCustomerInformationPage;
import com.tmo.tesa.pages.TesaEmailValidatePage;
import com.tmo.tesa.pages.TesaFinalConfirmationPage;
import com.tmo.tesa.pages.TesaIngenicoPrintDocumentPage;
import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.BaseSystem;
import com.tmo.tmag.pages.TmagAALExistingAccount;
import com.tmo.tmag.pages.TmagActivationConfirmationPage;
import com.tmo.tmag.pages.TmagActivationSummaryPage;
import com.tmo.tmag.pages.TmagActivationSummaryResultsPage;
import com.tmo.tmag.pages.TmagBillingInfoPage;
import com.tmo.tmag.pages.TmagFeaturesPage;
import com.tmo.tmag.pages.TmagHomePage;
import com.tmo.tmag.pages.TmagRatePlanAndDeviceSelectionPage;
import com.tmo.tmag.pages.TmagServiceSetup;

public class AddALineSystem extends BaseSystem {

	public final Logger log = LoggerFactory.getLogger(BasePage.class);

	TmagHomePage tmagHome;
	TmagAALExistingAccount tmagAALExistingAcct;
	private TmagRatePlanAndDeviceSelectionPage tmagRatePlanAndDeviceSelectionPage = new TmagRatePlanAndDeviceSelectionPage(driver);
	private TmagFeaturesPage tmagFeaturesPage = new TmagFeaturesPage(driver);
	private TmagServiceSetup tmagServiceSetUpPage = new TmagServiceSetup(driver);
	private TmagBillingInfoPage tmagBillingInfoPage =  new TmagBillingInfoPage(driver);
	private TmagActivationSummaryPage tmagActivationSummaryPage = new TmagActivationSummaryPage(driver);
	private TmagCustomerInformationPage tmagCustomerInformationPage =  new TmagCustomerInformationPage(driver);
	private TesaIngenicoPrintDocumentPage tesaPrintDoc = new TesaIngenicoPrintDocumentPage(driver);
	private TmagActivationSummaryResultsPage tmagActivationResults = new TmagActivationSummaryResultsPage(driver);
	private TesaEmailValidatePage tesaEmailValidate = new TesaEmailValidatePage(driver);
	private TmagActivationConfirmationPage tmagActivationConfirmation = new TmagActivationConfirmationPage(driver);
	private PosCustomerOverviewPage posCustOverview = new PosCustomerOverviewPage(driver);
	private DeviceTradeInQuoteTool deviceTradeInPage = new DeviceTradeInQuoteTool(driver);
	private PosItemEntryPage posItemEntry = new PosItemEntryPage(driver);
	private PosCalculatePaymentsPage posCalcPayments = new PosCalculatePaymentsPage(driver);
	private PosAddTenderPage posAddTender = new PosAddTenderPage(driver);
	private TesaFinalConfirmationPage tesaFinalConfirmation = new TesaFinalConfirmationPage(driver);


	public AddALineSystem(WebDriver webDriver) {
		super(webDriver);
	}

	public void newAddALine(String scenario) {
		try {
			tmagHome = new TmagHomePage(driver).newAddALine();
			tmagAALExistingAcct = new TmagAALExistingAccount(driver);
			tmagAALExistingAcct.searchByMsisdn(scenario);
			tmagAALExistingAcct.verifyCustomer(scenario);
		} catch (Exception e) {
			log.info("Error in search Msisdn and Customer Verirfication");
			MatcherAssert.assertThat("Search Msisdn is failed", false);
		}
	}

	public void selectRatePlanAndServiceSetup(String scenario, String sim) {
		try {
			if (TmagConstants.SCN_AAGSMIRNonPooledEIP.equals(scenario) || TmagConstants.SCN_AAMBIRNonPooledEIP.equals(scenario)) {
				tmagCustomerInformationPage.checkVoiceDataAndClick(scenario);
				tmagRatePlanAndDeviceSelectionPage.selectRatePlanAndDevice(TmagConstants.EIP_Pricing,sim);
			} else if (TmagConstants.SCN_AAGSMIRPooledFRP.equals(scenario)) {
				tmagRatePlanAndDeviceSelectionPage.selectRatePlanAndDevice("New Device",sim);
			} else if (TmagConstants.SCN_AAMBIRNonPooledEIPPRMArket.equals(scenario)) {
				tmagCustomerInformationPage.checkVoiceDataAndClick(scenario);
				tmagRatePlanAndDeviceSelectionPage.selectPricingOptions(TmagConstants.EIP_Pricing);
				tmagRatePlanAndDeviceSelectionPage.enterImei();
				tmagRatePlanAndDeviceSelectionPage.enterSim(sim);
				tmagRatePlanAndDeviceSelectionPage.enterSku();
				tmagRatePlanAndDeviceSelectionPage.validateDevice();
			} else {
				tmagCustomerInformationPage.checkVoiceDataAndClick(scenario);
				tmagRatePlanAndDeviceSelectionPage.selectRatePlanAndDevice(TmagConstants.EIP_Pricing,sim);
			}
			tmagFeaturesPage.selectFeatures(scenario);			
			tmagServiceSetUpPage.selectServiceSetup();
		} catch (Exception e) {
			log.info("Error in Rate Plan selection and Features");
			MatcherAssert.assertThat("Rate Plan selection and Features is failed", false);
		}
	}

	public void selectBillingInfo(String scenario) {
		try {
			tmagBillingInfoPage.unEnrollAutoPay();
			tmagBillingInfoPage.continueToSummary();
			tmagActivationSummaryPage.activateAndContinue();
		} catch (Exception e) {
			log.info("Error in selecting Billing info" + e.getMessage());
			MatcherAssert.assertThat("selecting the billing info is failed", false);
		}
	}
	
	public void continueFlow(String scenario) {
		try{
			tmagActivationResults.verifySuccessfulActivation();
			tesaEmailValidate.validateContinueEmail();
			tesaPrintDoc.closeAndContinue();
			tmagActivationConfirmation.isActivationSuccessful(scenario, scenario);
		} catch (Exception e) {
			log.info("Error in the flow before pos handoff" + e.getMessage());
			MatcherAssert.assertThat("Before pos handoff flow is failed", false);
		}	
		try {
			posCustOverview.acceptIngenicoNotConnnected();
			String activatedBan = "";
			String activatedMsisdn = "";
			activatedBan = posCustOverview.getBan();
			activatedMsisdn = posCustOverview.getMSISDN();
			posCustOverview.continueCustomerInformation();
			if(scenario.equals(TmagConstants.SCN_AAGSMEIPDRP)) {
				//pos yes btn click
				deviceTradeInPage.verifyActivationInfoPg();
				deviceTradeInPage.chooseAnswersAsYes();
				deviceTradeInPage.dragAndDropDevice();
				deviceTradeInPage.checkIMEI();
				posCalcPayments.calculatePaymentsAndContinue("175");
				posAddTender.selTenderType();
				posAddTender.addTender();
				posAddTender.handlePopups();
				tesaEmailValidate.skipAndContinue();
				tesaFinalConfirmation.isActivationSuccessful(activatedBan, activatedMsisdn);
			} else {
				posItemEntry.continueCalculateWithPayments();
				posCalcPayments.calculatePaymentsAndContinue("175");
				posAddTender.selTenderType();
				posAddTender.addTender();
				posAddTender.handlePopups();
				tesaEmailValidate.skipAndContinue();
				tesaFinalConfirmation.isActivationSuccessful(activatedBan, activatedMsisdn);
			}
		} catch (Exception e) {
			log.info("Error in the POS pages" + e.getMessage());
			MatcherAssert.assertThat("Actions in the POS pages is failed", false);
		}	
	}

}
