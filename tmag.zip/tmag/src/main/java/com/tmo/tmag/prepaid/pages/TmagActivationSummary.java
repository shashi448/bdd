package com.tmo.tmag.prepaid.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page object model for TMAG Activation Summary page.
 * @author Prince
 *
 */
public class TmagActivationSummary extends TmagBillingInformation {
	
	/**
	 * Activate and Continue button.
	 */
	@FindBy(css = "#nextButton")
	private WebElement btnActivateAndContinue;

	public TmagActivationSummary(WebDriver driver) {
		super(driver);
	}

}
