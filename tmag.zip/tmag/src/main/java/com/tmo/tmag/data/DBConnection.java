package com.tmo.tmag.data;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

/**
 * This class retrieves a DB connection
 * @author seperias
 *
 */
public class DBConnection {
	
	private static final String DB_PROPERTIES = "Database.properties";

	/**
	 * This method gets the property value from Database.properties
	 * @param key
	 * @return
	 */
	public String getProperty(String key) {
		Properties properties = new Properties();
		InputStream inputStream = null; 
		try {
			
			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			inputStream = classloader.getResourceAsStream(DB_PROPERTIES);
			
			if(inputStream==null){
	            System.out.println("Unable to find Messages.properties file!" );
	  		}	  		
	  		properties.load(inputStream);	  		
		}
		catch(IOException exception) {
			exception.printStackTrace();
			
		}
		finally {
			try {
				if(inputStream != null) {
					inputStream.close();
				}
			}catch(IOException exp) {}
		}
		return properties.getProperty(key);		
  	}
	
	/**
	 * This method gets the SAMSON connection object
	 * @param envTag
	 * @return
	 */
	public Connection getSamsonConnection(String envTag) {
		String jdbcUrl;
		String userId;
		String password;
		
		Connection conn = null;
		envTag = envTag.toLowerCase();
		
		if(!"".equalsIgnoreCase(envTag) && envTag!= null) {
			jdbcUrl = getProperty(envTag + "." +  "samson.jdbc.url");
			userId = getProperty(envTag + "." +  "samson.userid");
			password = getProperty(envTag + "." +  "samson.password");
		}
		else {
			jdbcUrl = getProperty("samson.jdbc.url");
			userId = getProperty("samson.userid");
			password = getProperty("samson.password");
		}
		
		try {
			
			OracleDataSource ds = new OracleDataSource();
			ds.setURL(jdbcUrl);

			conn = ds.getConnection(userId, password);
		}
		catch(SQLException exp) {
			exp.printStackTrace();
		}
		if(conn != null) {
			return conn;
		}
		else {
			return null;
		}
	}
		
	/**
	 * This method executes the select query and returns the result set
	 * @param conn
	 * @param sqlQuery
	 * @return
	 */
	public ResultSet getResultSetForSelect(Connection conn, String sqlQuery) {
		Statement stmt = null;
		ResultSet resultSet = null;
		
		try {
			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			resultSet = stmt.executeQuery(sqlQuery);
		}
		catch(SQLException exp) {
			exp.printStackTrace();
		}
			
		return resultSet;
	}

	public Connection getPrepaidConnection(String envTag) {
		String jdbcUrl;
		String userId;
		String password;
		
		Connection connPrepaid = null;
		envTag = envTag.toLowerCase();
		
		if(!"".equalsIgnoreCase(envTag) && envTag!= null) {
			jdbcUrl = getProperty(envTag + "." +  "prepaid.jdbc.url");
			userId = getProperty(envTag + "." +  "prepaid.userid");
			password = getProperty(envTag + "." +  "prepaid.password");
		}
		else {
			jdbcUrl = getProperty("prepaid.jdbc.url");
			userId = getProperty("prepaid.userid");
			password = getProperty("prepaid.password");
		}
		
		System.out.println(jdbcUrl+">>>"+userId+">>>"+password);
		
		try {
			
			OracleDataSource ds = new OracleDataSource();
			ds.setURL(jdbcUrl);

			connPrepaid = ds.getConnection(userId, password);
		}
		catch(SQLException exp) {
			exp.printStackTrace();
		}
		if(connPrepaid != null) {
			return connPrepaid;
		}
		else {
			return null;
		}
	}
}
