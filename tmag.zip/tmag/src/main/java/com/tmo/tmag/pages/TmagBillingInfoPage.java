package com.tmo.tmag.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TmagBillingInfoPage extends TmagServiceSetup {

	@FindBy(css = "input[id='billPayPreferenceAutoPay']")
	private WebElement chkbxEnrollAutoPay;

	@FindBy(css = "#billPayPreferenceSavePaymentMethod")
	private WebElement chkbxSavePaymentMethod;

	@FindBy(css = "#nextButton")
	private WebElement btnContinueToSummary;
	
	@FindBy(css="select[id='paymentOptions']")
	private WebElement cmbPaymentOptions;
	
	@FindBy(css="input[id='accountNumber']")
	private WebElement txtAccountNumber;
	
	@FindBy(css="input[id='routingNumber']")
	private WebElement txtRoutingNumber;

	public TmagBillingInfoPage(WebDriver driver) {
		super(driver);
	}

	public TmagBillingInfoPage unEnrollAutoPay() {
		try{
		verifyPageLoad("TMAG Billing Info");
		if (chkbxEnrollAutoPay.isSelected()) {
			click(chkbxEnrollAutoPay);
		}
		if (chkbxSavePaymentMethod.isSelected()) {
			click(chkbxSavePaymentMethod);
		}
		} catch (Exception e) {
			log.info("Error in Billing info page"+e);
		}
		return this;
	}
	
	public TmagBillingInfoPage unEnrollAutoPayCostco() {
		verifyPageLoad("TMAG Billing Info");
		if (chkbxEnrollAutoPay.isSelected()) {
			click(chkbxEnrollAutoPay);
		}
		return this;
	}

	public TmagBillingInfoPage continueToSummary() {
		waitAndClick(btnContinueToSummary, 30);
		return this;
	}

	public TmagBillingInfoPage selectPaymentMethod() {
		setValue(cmbPaymentOptions, "New Electronic Check");
		setValue(txtAccountNumber,"89958100313777");
		setValue(txtRoutingNumber,"325081403");
		return this;
	}
	public TmagBillingInfoPage enrollAutoPayAndContinue() {
		selectPaymentMethod();
		continueToSummary();
		return this;
	}

}
