package com.tmo.tmag.pages;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tmo.pages.base.TmagConstants;
import com.tmobile.apptests.common.utils.DatabaseManager;

public class TmagAALExistingAccount extends TmagHomePage {
	
	public final Logger log = LoggerFactory.getLogger(TmagAALExistingAccount.class);
	@FindBy(css="#msisdn")
	private WebElement txtFldMsisdn;
	
	@FindBy(css="#password")
	private WebElement txtFldPin;
	
	@FindBy(css="#searchByMSISDN")
	private WebElement btnSearch;
	
	@FindBy(css="#customer0")
	private WebElement rdbtnCustomer;
	
	@FindBy(css="#numServReq")
	private WebElement drpdwnVoiceLines;

	@FindBy(id = "numMBBServReq")
	private WebElement cmbbLines;

	@FindBy(css = "#nextButton")
	private WebElement btnContinueToRatePlanAndDevice;

	@FindBy(css = "select[id='markets']")
	private WebElement cmbMarkets;

	private String pin;
	private String msisdn;

	public TmagAALExistingAccount(WebDriver webDriver) {
		super(webDriver);
	}

	private TmagAALExistingAccount getAALData(String level) {
		String socLevelCode;
		String defualtSubType = "R";
		if ("Pooled".equals(level)) {
			socLevelCode = "P";
			defualtSubType = "A";
			
		} else {
			socLevelCode = "C";
		}
		DatabaseManager db = new DatabaseManager();
		Connection conn = db.getDB(System.getProperty("testEnv"));
		String selectSQL = "Select acc_password,t1.ban,t1.subscriber_no,t1.Soc,t1.SOC_Level_code,BA.Credit_Class,BA.Default_SUB_Market,BA.sys_creation_date ,C.Customer_SSN, "
				+ "C.tax_id,t1.product_type from Service_Agreement t1, (select ban,subscriber_no,SOC,Expiration_Date from service_agreement "
				+ "where Service_Type='P' and Subscriber_no in(select Subscriber_no  from subscriber  where  SUB_Status='A') "
				+ "and Expiration_date is null Order by BAN) T2, Billing_Account BA,Customer C where t1.ban=t2.ban and acc_password ='1234' "
				+ "and T1.Subscriber_no=T2.Subscriber_no and T1.Service_Type='P' and t1.BAN=BA.BAN and C.Customer_id=t1.BAN "
				+ "and BA.BAN in (Select BAN from Billing_account where BAN_STATUS='O' and COL_DELINQ_STATUS='N') "
				+ "and BA.Account_Type='I' and BA.Account_Sub_Type='"+defualtSubType+"' and T1.Soc_Level_Code='" + socLevelCode
				+ "' order by ba.sys_creation_date desc ";
		ResultSet rset = db.sendSelect(conn, selectSQL);
		try {
			rset.absolute(new Random().nextInt(1000));
			if (rset.next()) {
				pin = rset.getString("acc_password");
				msisdn = rset.getString("subscriber_no");
				log("Selected MSISDN: " + rset.getString("subscriber_no") + "PIN: " + rset.getString("acc_password"));
				db.closeDB(conn);
			}
		} catch (SQLException e) {
			log.info("Error in retrieving the customer information from db method getAALData" + e);
			MatcherAssert.assertThat("Data retrieval from db failed for methodgetAALData.", false);
		} finally {
			db.closeDB(conn);
		}
		return this;
	}

	private TmagAALExistingAccount getAALCustomerWithAutoPay() {
		DatabaseManager db = new DatabaseManager();
		Connection conn = db.getDB(System.getProperty("testEnv"));
		String selectSQL = "SELECT acc_password,t1.ban,t1.subscriber_no,t1.soc,t1.soc_level_code,ba.credit_class,ba.default_sub_market,ba.sys_creation_date,c.customer_ssn,c.tax_id,t1.product_type"+
		" FROM service_agreement t1,(SELECT ban,subscriber_no,soc,expiration_date FROM service_agreement WHERE service_type = 'P' AND subscriber_no IN (SELECT subscriber_no FROM subscriber WHERE sub_status = 'A')"+
		" AND expiration_date IS NULL ORDER BY ban) t2,billing_account ba,customer c WHERE t1.ban = t2.ban AND acc_password = '1234' AND t1.subscriber_no = t2.subscriber_no AND t1.service_type = 'P' AND t1.ban = ba.ban AND c.customer_id = t1.ban AND ba.ban IN (SELECT ban FROM billing_account WHERE ban_status = 'O' AND col_delinq_status = 'N') AND ba.account_type = 'I' AND ba.account_sub_type = 'R'"+
		" AND t1.soc_level_code = 'C' AND t1.ban in (select ban from ban_direct_debit where dd_status = 'A' and operator_id = '1000')";

		ResultSet rset = db.sendSelect(conn, selectSQL);
		try {
			rset.absolute(new Random().nextInt(1000));
			if (rset.next()) {
				pin = rset.getString("acc_password");
				msisdn = rset.getString("subscriber_no");
				log("Selected MSISDN: " + rset.getString("subscriber_no") + "PIN: " + rset.getString("acc_password"));
				db.closeDB(conn);
			}
		} catch (SQLException e) {
			log.info("Error in retrieving the customer information from db method getAALData" + e);
			MatcherAssert.assertThat("Data retrieval from db failed for methodgetAALData.", false);
		} finally {
			db.closeDB(conn);
		}
		return this;
	}

	private void setAALData(String level) {
		getAALData(level);
	}

	public TmagAALExistingAccount searchByMsisdn(String scenario) {
		verifyPageLoad("TMAG AAL Search");
		if (TmagConstants.SCN_AAGSMIRNonPooledEIP.equals(scenario)) {
			setAALData(TmagConstants.Non_Pooled);
		} else if (TmagConstants.SCN_AAGSMIRPooledFRP.equals(scenario)) {
			setAALData("Pooled");
		} else if (TmagConstants.SCN_AAMBIRNonPooledEIP.equals(scenario)) {
			getAALCustomerWithAutoPay();
		} else if (TmagConstants.SCN_AAMBIRNonPooledEIPPRMArket.equals(scenario)) {
			setAALData("NonPooled");
		} else {
			setAALData("NonPooled");
		}
		try {
			setValue(txtFldMsisdn, msisdn);
			setValue(txtFldPin, pin);
			click(btnSearch);
			log("Searching for MSISDN " + msisdn + " using pin " + pin);
		} catch (Exception e) {
			log.info("Error in Search Customer By Msisdn " + e);
			MatcherAssert.assertThat("Search Customer By Msisdn is failed", false);
		}
		return this;
	}

	public TmagAALExistingAccount verifyCustomer(String scenario) {
		try {
			if (isElementPresent(rdbtnCustomer)) {
				log("Customer found!");
				assertMatcher("Customer found for AAL!", true);
				if (TmagConstants.SCN_AAGSMIRNonPooledEIP.equals(scenario)
						|| TmagConstants.SCN_AAGSMIRPooledFRP.equals(scenario)) {
					selectByIndex(drpdwnVoiceLines, 1);
					log(TmagConstants.Single_Voice_line);
				} else if (TmagConstants.SCN_AAMBIRNonPooledEIP.equals(scenario)) {
					selectByIndex(cmbbLines, 1);
					log(TmagConstants.Single_Data_line);
				} else if (TmagConstants.SCN_AAMBIRNonPooledEIPPRMArket.equals(scenario)) {
					selectByIndex(cmbbLines, 1);
					log(TmagConstants.Single_Voice_line);
				} else {
					selectByIndex(drpdwnVoiceLines, 1);
					log("Selected 1 additional voice line");
				}
				waitAndClick(btnContinueToRatePlanAndDevice, 10);
				log("Clicked on Continue to Rate Plan and Device button.");
			} else {
				log("Customer search failed.");
				assertMatcher("Customer search failed.", false);
			}
		} catch (Exception e) {
			log("Error in customer verification and voice or data selection.");
			assertMatcher("Customer verification failed.", false);
		}
		return this;
	}

}
