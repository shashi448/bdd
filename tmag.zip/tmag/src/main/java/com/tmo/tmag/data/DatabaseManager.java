package com.tmo.tmag.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

public class DatabaseManager {

	public Connection getDB(String envTag) {

		if (envTag == null) {
			envTag = "qlab02";
		}

		DBConnection dbConn = new DBConnection();
		Connection conn;
		conn = dbConn.getSamsonConnection(envTag);

		if (conn != null) {

			System.out.println("Successful conncetion to: " + envTag);
			return conn;

		} else {
			System.out.println("Failed to connect to: " + envTag);
		}
		return null;
	}

	public ResultSet sendSelect(Connection conn, String sql) {
		Statement stmt;
		ResultSet rset;

		try {

			stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);

			System.out.println("\nExecuting query: " + sql);

			rset = stmt.executeQuery(sql);
			return rset;

		} catch (SQLException e) {
			e.printStackTrace();
			closeDB(conn);
		}

		return null;
	}

	public void sendUpdate(Connection conn, String sql) {
		try {
			System.out.println("\nExecuting query: " + sql);

			conn.setAutoCommit(false);
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			closeDB(conn);
		}
	}

	public String getSimUpdateStatus(Integer index, String engTag) {

		DatabaseManager db = new DatabaseManager();
		Connection conn = getDB(engTag);

		String selectSQL = "SELECT * FROM SERIAL_ITEM_INV WHERE RESOURCE_STATUS ='AA' AND SERIAL_NUMBER  LIKE '89012%' AND SERIAL_NUMBER NOT IN (SELECT UNIT_ESN FROM PHYSICAL_DEVICE)AND LENGTH(SERIAL_NUMBER)=19 AND SIM_TYPE in('MV','UC') And Service_Partner_Id = 'TMO' and (sim_expiration_date is null or sim_expiration_date >sysdate) and SIM_type <>'2' And Impi1 Is Null ORDER BY SYS_CREATION_DATE ASC";
		String sim;

		ResultSet rset = sendSelect(conn, selectSQL);

		try {
			if (rset.next()) {
				if (index > 0) {
					// rset.next();
					try {
						int row = 1 + (int) (Math.random() * ((5 - 1) + 1));
						rset.absolute(row);
					} catch (Exception e) {
					}
				}
				sim = rset.getString("serial_number");
				System.out.println("Selected SIM: " + sim + "Resource_Status: " + rset.getString("resource_status"));

				if (!rset.getString("resource_status").equals("AA")) {

					String updateSQL = "Update SERIAL_ITEM_INV set resource_status='AA',SIM_EXPIRATION_DATE='',GBA_SIM ='Y',SERVICE_PARTNER_ID='TMO' where SERIAL_NUMBER = '"
							+ sim + "'";
					db.sendUpdate(conn, updateSQL);

					String selectSQL2 = "select serial_number, resource_status from serial_item_inv where SERIAL_NUMBER = '"
							+ sim + "'";

					ResultSet rset2 = db.sendSelect(conn, selectSQL2);
					if (rset2.next()) {
						System.out.println("SIM: " + rset2.getString("serial_number") + " updated to Resource_Status: "
								+ rset2.getString("resource_status"));
					}
				}

				db.closeDB(conn);
				return sim;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			db.closeDB(conn);
		}

		return null;
	}

	public void closeDB(Connection conn) {
		try {
			conn.close();

			if (conn.isClosed()) {
				System.out.println("\nConnection Closed!");
			} else {
				System.out.println("Failed to close connection!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}