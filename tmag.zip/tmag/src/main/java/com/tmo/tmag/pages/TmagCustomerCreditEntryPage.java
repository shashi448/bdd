package com.tmo.tmag.pages;

import java.sql.SQLException;

import org.jsoup.select.Evaluator.IsEmpty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.sun.javafx.collections.MappingChange.Map;
import com.tmo.tmag.base.Properties;

import com.tmobile.apptests.common.utils.DatabaseManager;
import com.tmobile.eqm.testfrwk.ui.core.httpclient.TestDataService;

/**
 * Customer Credit Entry Page Model.
 * 
 * @author Prince
 *
 */
public class TmagCustomerCreditEntryPage extends TmagHomePage {

	/**
	 * Credit check radio button 'yes'.
	 */
	@FindBy(css = "#creditCheckYes")
	private WebElement rdbtnCreditCheckYes;

	@FindBy(css = "#consentYes")
	private WebElement rdbtnconsentAgreementYes;
	/**
	 * First name text field.
	 */
	@FindBy(css = "#firstName")
	private WebElement txtFirstName;

	/**
	 * Middle initial text field.
	 */
	@FindBy(css = "#midInit")
	private WebElement txtInitial;

	/**
	 * Last name text field.
	 */
	@FindBy(css = "#lastName")
	private WebElement txtLastName;

	/**
	 * Address line 1 text field.
	 */
	@FindBy(css = "#address1")
	private WebElement txtAddress1;

	/**
	 * Zip code text field.
	 */
	@FindBy(css = "#zip")
	private WebElement txtZip;

	/**
	 * State drop down.
	 */
	@FindBy(css = "#state")
	private WebElement txtState;

	/**
	 * City text field.
	 */
	@FindBy(css = "#city")
	private WebElement txtCity;

	/**
	 * Drivers license drop down.
	 */
	@FindBy(css = "#id")
	private WebElement txtID;

	/**
	 * SSN text field.
	 */
	@FindBy(css = "#ssn")
	private WebElement txtSSN;

	/**
	 * SSN confirm text field.
	 */
	@FindBy(css = "#ssnconfirm")
	private WebElement txtSSNConfirm;

	/**
	 * Birthday text field (MM/DD/YYYY).
	 */
	@FindBy(css = "#birthDate")
	private WebElement txtDOB;

	/**
	 * Home phone text field.
	 */
	@FindBy(css = "#homePhone")
	private WebElement txtPhone;

	/**
	 * Pin text field.
	 */
	@FindBy(css = "#pin")
	private WebElement txtPIN;

	/**
	 * Email text field.
	 */
	@FindBy(css = "#emailCreditPage")
	private WebElement txtEmail;

	/**
	 * Check credit button.
	 */
	@FindBy(css = "#checkCreditButton")
	private WebElement btnCreditCheck;

	/**
	 * Continue to Rate Plan and Device button.
	 */
	@FindBy(css = "#nextButton")
	private WebElement btnContinueToRatePlanAndDevice;

	@FindBy(css = "#patriotActcheck")
	private WebElement rdbtnNoticeRead;
	
	public TmagCustomerCreditEntryPage(WebDriver driver) {
		super(driver);
	}

	public TmagCustomerCreditEntryPage creditAuthorization() {
		verifyPageLoad("TMAG Credit Check");
		click(rdbtnCreditCheckYes);
		if((rdbtnNoticeRead.isDisplayed())&&(!rdbtnNoticeRead.isSelected())){
			log("Patriot notice present, Yes selection need to be clicked");
			click(rdbtnNoticeRead);
		}
		if((rdbtnconsentAgreementYes.isDisplayed())&&(!rdbtnconsentAgreementYes.isSelected())){
			log("Consent agreement present, Yes selection need to be clicked");
			click(rdbtnconsentAgreementYes);
		}
		return this;
	}

	@SuppressWarnings("null")
	private String retrieveAvailableSSN() {
		String resultSsn = null;
		try
		{
		TestDataService dataService = new TestDataService();
	    java.util.Map<String, String> SSNVal = dataService.getScenario(System.getProperty("testEnv"),"customer_ssn");
        if ((SSNVal!=null) || (!SSNVal.equals(""))){
        	for (String value : SSNVal.values()) {
        	resultSsn = value;
        	log("ssn retrieved using TDM method");
     	}}
        else {
        	resultSsn = "";
        	log("ssn retrieval using TDM method failed, moving to TD method");
        }
		if ((resultSsn==null) || (resultSsn.equals(""))){
			DatabaseManager db = new DatabaseManager();
			resultSsn = db.getSSN(System.getProperty("testEnv"));
		}
		if (resultSsn.isEmpty()) {
			log("Sim Retrieval Failed.");
			assertMatcher("Sim Retrieval from DB and TDM API failed.", false);
		}
		log("SSN: " + resultSsn);
	} catch (SQLException e) {
			log("Exception occurred while retrieving SSN from db  " + e);
		}
		return resultSsn;}
	
	public TmagCustomerCreditEntryPage fillForm(String ssn) {
		setValue(txtFirstName, Properties.getUserProperty("firstName"));
		setValue(txtInitial, Properties.getUserProperty("middleInitial"));
		setValue(txtLastName, Properties.getUserProperty("lastName"));
		setValue(txtAddress1, Properties.getUserProperty("address1"));
		setValue(txtZip, Properties.getUserProperty("zip"));
		setValue(txtID, Properties.getUserProperty("licenseId"));
		log("SSN retreival started");
		if (ssn.isEmpty()) {
		ssn = retrieveAvailableSSN();
		}
		setValue(txtSSN, ssn);
		setValue(txtSSNConfirm, ssn);
		setValue(txtDOB, Properties.getUserProperty("birthday"));
		setValue(txtPhone, Properties.getUserProperty("contactNumber"));
		setValue(txtPIN, Properties.getUserProperty("pin"));
		return this;
	}

	public TmagCustomerCreditEntryPage performCreditCheckAndContinue() {
		click(btnCreditCheck);
		// After credit check, page will automatically go to next page.
		return this;
	}
	
	public TmagCustomerCreditEntryPage verifyPage() {
		
		return this;
	}

}
