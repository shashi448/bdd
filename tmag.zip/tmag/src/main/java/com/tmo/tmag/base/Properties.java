package com.tmo.tmag.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Properties {
	private static java.util.Properties urlProps;
	private static java.util.Properties userProps;
	private static java.util.Properties credentialsProps;

	private static final Logger PropLog = LoggerFactory.getLogger(Properties.class);

	private Properties() {
		// Restricting public access
	}

	static {
		FileInputStream in = null;
		urlProps = new java.util.Properties();
		try {
			final File propertiesFile = new File("./src/test/resources/properties/url.properties");
			if (propertiesFile.exists()) {
				in = new FileInputStream(propertiesFile);
				urlProps.load(in);
			} else {
				PropLog.info("Faild reading application.properties");
				System.exit(1);
			}
		} catch (IOException ioe) {
			PropLog.info(ioe.getMessage());
		}

		in = null;
		userProps = new java.util.Properties();
		try {
			final File propertiesFile = new File("./src/test/resources/properties/user.properties");
			if (propertiesFile.exists()) {
				in = new FileInputStream(propertiesFile);
				userProps.load(in);
			} else {
				PropLog.info("Faild reading db.properties");
				System.exit(1);
			}
		} catch (IOException ioe) {
			PropLog.info(ioe.getMessage());
		}
		
		in = null;
		credentialsProps = new java.util.Properties();
		try {
			final File propertiesFile = new File("./src/test/resources/properties/credentials.properties");
			if (propertiesFile.exists()) {
				in = new FileInputStream(propertiesFile);
				credentialsProps.load(in);
			} else {
				PropLog.info("Faild reading db.properties");
				System.exit(1);
			}
		} catch (IOException ioe) {
			PropLog.info(ioe.getMessage());
		}

	}

	public static String getURLProperty(String key) {
		return urlProps.getProperty(key);
	}

	public static String getUserProperty(String key) {
		return userProps.getProperty(key);
	}
	
	public static String getCredentialsProperty(String key) {
		return credentialsProps.getProperty(key);
	}

}