package com.tmo.tmag.base;

import java.util.Set;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.DefaultElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;




public class TmagBasePage {
	
	private final Logger log = LoggerFactory.getLogger(TmagBasePage.class);
	private WebDriver driver;
	private static final String reportVal = "Value: ";
	
	public TmagBasePage(WebDriver driver) {
		this.setDriver(driver);
		initPage();
	}
	
	private void initPage() {
		DefaultElementLocatorFactory decorator = new DefaultElementLocatorFactory(driver);
		PageFactory.initElements(decorator, this);
	}
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public void click(WebElement ele) {
		waitFor(ele, 30);
		ele.click();
		log("Click performed on element: " + ele);
	}
	
	public void waitAndClick(WebElement ele, int time) {
		waitForClick(ele, time);
		ele.click();
		//log("Click performed on element: " + ele);
		//waitForPageToLoad();
	}
	
	public void setValue(WebElement ele, String str) {
		waitFor(ele, 30);
		ele.sendKeys(str);
		ele.sendKeys(Keys.TAB);
		log(reportVal + str + " is set to element: " + ele);
	}
	
	public void selectByText(WebElement ele, String str){
		waitFor(ele, 30);
		Select select = new Select(ele);
		select.selectByVisibleText(str);
		log(reportVal + str + " is selected from " + ele);
	}
	
	public void selectByIndex(WebElement ele, int index){
		waitFor(ele, 30);
		Select select = new Select(ele);
		select.selectByIndex(index);
		log(reportVal + select.getOptions().get(index) + " is selected from " + ele);
	}
	
	
	
	public void log(String str) {
		log.info(str);
	}

	protected void waitFor(WebElement ele) {
		waitForPageToLoad();
		log("Waiting 60 seconds for element: " + ele + " to be visible.");
		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(ele));
		} catch(Exception e) {
			MatcherAssert.assertThat(ele + " is not visible within 60 seconds.", false);
			throw new RuntimeException(e);
		}
	}
	
	protected void waitFor(WebElement ele, int time) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, time).until(ExpectedConditions.visibilityOf(ele));
		} catch(Exception e) {
			MatcherAssert.assertThat(ele + " is not visible within "+time+" seconds.", false);
			throw new RuntimeException(e);
		}
	}
	
	protected void waitForClick(WebElement ele, int time) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, time).until(ExpectedConditions.elementToBeClickable(ele));
		} catch(Exception e) {
			MatcherAssert.assertThat(ele + " is not clickable within "+time+" seconds.", false);
			throw new RuntimeException(e);
		}
	}
	
	protected void waitForClick(WebElement ele) {
		waitForPageToLoad();
		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.elementToBeClickable(ele));
		} catch(Exception e) {
			MatcherAssert.assertThat(ele + " is not clickable within 60 seconds.", false);
			throw new RuntimeException(e);
		}
	}
	
	private void waitForPageToLoad() {
		new WebDriverWait(driver, 30).until((ExpectedCondition<Boolean>) wd -> ((JavascriptExecutor) wd)
				.executeScript("return document.readyState").equals(Constants.complete.toString()));
	}
	
	/**
	 * Method to check if the Alert is Present or Not.
	 * @return
	 */
	public boolean isAlertPresent(){
		
	    boolean foundAlert = false;
	    WebDriverWait wait = new WebDriverWait(getDriver(), 2 /*timeout in seconds*/);
	    try {
	        wait.until(ExpectedConditions.alertIsPresent());
	        foundAlert = true;
	    } catch (TimeoutException eTO) {
	    	log.error("Error in system use agreement",eTO);
	        foundAlert = false;
	    }
	    return foundAlert;
	}

	/**
	 * Verify Window Presence By passing the URL as Parameter
	 * @param urlToSwitch - Parameter as URL to switch
	 * @return boolean value
	 */
	public boolean verifyWindowPresenceByURL(String urlToSwitch) {

		Set<String> allWindows = getDriver().getWindowHandles();
		boolean windowexist = false;
		for (String currentWindow : allWindows){
			if (getDriver().switchTo().window(currentWindow).getCurrentUrl().contains(urlToSwitch)){
				getDriver().switchTo().window(currentWindow);
				windowexist = true;
				return true;
			}
		}
			return windowexist;
	}
	
	public void switchToWindowByURL(String urlToSwitch) {
		Set<String> allWindows = getDriver().getWindowHandles();
		for (String currentWindow : allWindows) {
			if (getDriver().switchTo().window(currentWindow).getCurrentUrl().contains(urlToSwitch)) {
				getDriver().switchTo().window(currentWindow);
				return;
			}
		}
	}
	public void verifyCertificate() {
		if(driver.getTitle().equalsIgnoreCase("Certificate Error: Navigation Blocked")){
			waitAndClick(driver.findElement(By.cssSelector("#overridelink")), 20);
		}
	
	}
	
	public void navigateTo(String url){
		driver.navigate().to(url);
	}

	public void getParentWindow() {
		getDriver().switchTo().window(getDriver().getWindowHandle());
	}
	
	public TmagBasePage updateURL() {
		verifyCertificate();
		String url = getDriver().getCurrentUrl();
		if(!url.contains("qatwswatx532.gsm1900.org")){
			url = url.replace("qatwswatx532", "qatwswatx532.gsm1900.org");
			getDriver().get(url);
		}
		if(!url.contains("qatwswatx522.gsm1900.org")){ 
			url = url.replace("qatwswatx522", "qatwswatx522.gsm1900.org");
			getDriver().get(url);
		}
		if(!url.contains("qatwswatx162.gsm1900.org")){ 
			url = url.replace("qatwswatx162", "qatwswatx162.gsm1900.org");
			getDriver().get(url);
		}		
		return this;
	}
	
	public void setMacIDCookie(String macID,WebDriver driver) {
		Cookie ck = new Cookie("MacId", macID); //00059a3c7800
		driver.manage().addCookie(ck);
		ck = new Cookie("NetID", macID); //00059a3c7800
		driver.manage().addCookie(ck);
	}

	public void switchFrame(WebElement ele)
	{
		try{
			waitFor(ele);
			driver.switchTo().frame(ele);
		}catch (ElementNotVisibleException e) {
			MatcherAssert.assertThat(ele + " is not visible within 60 seconds.", false);
			throw new RuntimeException(e);
		}
	}
	
	public boolean isElementPresent(WebElement ele)
	{
		boolean flag = false;
		try{
			if(ele.isDisplayed())
				flag = true;
		}
		catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	
	public void close() {
		getDriver().close();
	}
	
}
