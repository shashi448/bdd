package com.tmo.tmag.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.hamcrest.MatcherAssert;
import com.tmo.pages.pos.PosHomepage;
import com.tmo.pages.tmag.PrepaidMenuPage;
import com.tmo.tmag.base.Properties;
/**
 * TMAG Home Page Object Model.
 * @author Rajesh Ravi
 *
 */
public class TmagHomePage extends TmagLoginPage {
	
	@FindBy(css = "#appLinkPersonalAccount")
	private WebElement lnkPersonalAccount;
	
	@FindBy(css = "#store")
	private WebElement lnkChangeStore;
	
	@FindBy(css="#storeNo")
	private WebElement txtFldStoreId;
	
	@FindBy(css="#searchBt")
	private WebElement btnSearch;
	
	@FindBy(css="#1")
	private WebElement btnConfirmStore;
	
	@FindBy(css="#logOut")
	private WebElement lnkLogOut;
	
	@FindBy(css="#appLinkAddToExisting")
	private WebElement lnkAddToExisting;
	
	@FindBy(css = "#logOut")
	private WebElement logoutLnk;

	@FindBy(css = "#appLinkPrepaidMenu")
	private WebElement prepaidMenuLnk;

	@FindBy(css="#storeinfo")
	private WebElement storeInfo;

	public TmagHomePage(WebDriver webDriver) {
		super(webDriver);
	}
	
	public TmagHomePage newPersonalAccount() {
		try{
			log("TMAG personal account navigation click started");
			verifyPageLoad("TMAG Home");
			click(lnkPersonalAccount);
		}catch (Exception e) {
			log("TMAG personal account navigation click failed");
			MatcherAssert.assertThat("TMAG personal account navigation click failed.", false);
		}
		return this;
	}
	
	public TmagHomePage validateStoreAndTill() {
		try{
			log("TMAG personal account navigation click started");
			waitForClick(prepaidMenuLnk, 30);
			waitFor(storeInfo);
			log("Store is not Open" + storeInfo.getText().contains(PosHomepage.storeValue));
		}catch (Exception e) {
			log("TMAG store or till not open. validateStoreAndTill - failed");
			MatcherAssert.assertThat("TMAG store or till not open. validateStoreAndTill - failed", false);
		}
		return this;
	}
	
	public TmagHomePage newAddALine() {
		click(lnkAddToExisting);
		return this;
	}
	
	public PrepaidMenuPage clickPrepaidMenuLnk() {
		try{
			log("TMAG prepaid navigation click started");
			waitAndClick(prepaidMenuLnk, 30);
		}
		catch (Exception e) {
			log("TMAG prepaid navigation click failed");
			MatcherAssert.assertThat("TMAG prepaid navigation click failed" + prepaidMenuLnk + " is not visible within 60 seconds.", false);
		}
		return get(PrepaidMenuPage.class);
	}


}
