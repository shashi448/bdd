package com.tmo.data;

public class ALMData {
	/*alm.createAlmUpdate("ENTERPRISE", "2017_ENTERPRISE_TEST", "4318919", "429053", "Passed", "120");
	alm.createAlmUpdate(domain, project, testId, testSetId, testExecutionResult, testDuration);*/
	private String domain = "ENTERPRISE";
	private String project = "2017_ENTERPRISE_TEST";
	private String testId;
	private String testSetId;
	private String testExecutionResult;
	private String testDuration;
	
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getTestSetId() {
		return testSetId;
	}
	public void setTestSetId(String testSetId) {
		this.testSetId = testSetId;
	}
	public String getTestExecutionResult() {
		return testExecutionResult;
	}
	public void setTestExecutionResult(String testExecutionResult) {
		this.testExecutionResult = testExecutionResult;
	}
	public String getTestDuration() {
		return testDuration;
	}
	public void setTestDuration(String testDuration) {
		this.testDuration = testDuration;
	}
}
