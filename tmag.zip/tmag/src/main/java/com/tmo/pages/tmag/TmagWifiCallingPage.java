package com.tmo.pages.tmag;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.pages.TmagServiceSetup;

public class TmagWifiCallingPage extends TmagRatePlanFeatures {

	@FindBy(css = "input[value='Do Not Accept'][type='button']")
	private WebElement decline911;

	@FindBy(css = "frame[name='middle']")
	private WebElement framemiddle;

	public TmagWifiCallingPage(WebDriver driver) {
		super(driver);
	}

	public TmagServiceSetup E911AddressPrepaid() {
		try {
			log("911 prepaid decline page action started");
			getDriver().switchTo().defaultContent();
			switchFrame(framemiddle);
			if (isElementPresent(decline911)) {
				decline911.click();
				log("Clicking Decline Button");
			}
			getDriver().switchTo().defaultContent();
		} catch (Exception e) {
			log("911 prepaid decline page action failed");
			MatcherAssert.assertThat("E911AddressPrepaid failed.", false);
		}
		return get(TmagServiceSetup.class);
	}
}
