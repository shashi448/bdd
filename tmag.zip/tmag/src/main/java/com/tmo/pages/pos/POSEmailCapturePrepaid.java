package com.tmo.pages.pos;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tmobile.apptests.common.general.CommonUtils;

import oracle.net.aso.e;

public class POSEmailCapturePrepaid extends PosCustomerInformation {

	@FindBy(css = "#MainFrame")
	private WebElement mainFrame;

	@FindBy(css = "iframe[name='Status']")
	private WebElement status;

	@FindBy(css = "input[name='ButtonCalc'][value='Calculate/Continue']")
	private WebElement btnCalc;

	@FindBy(css = "#TenderType")
	private WebElement selectTender;

	@FindBy(css = "#TenderType>option[value='0']")
	private WebElement selectTenderAsCash;

	@FindBy(css = "#Entry")
	private WebElement entryframe;

	@FindBy(css = "#TenderAmt")
	private WebElement amountValue;

	@FindBy(css = "#totalDisplay")
	private WebElement totalBalanceDisplay;

	@FindBy(css = "#tenderButton")
	private WebElement addBtn;

	@FindBy(css = "input[value='Ok']")
	private WebElement okBtn;

	@FindBy(css = "input[value='Skip']")
	private WebElement skipBtn;

	@FindBy(css = "input[value='Close']")
	private WebElement closeDocumentBtn;

	@FindBy(css = "input[value='Close']")
	private WebElement closeBtn;

	@FindBy(css = "#frmL")
	private WebElement frmL;

	@FindBy(css = "[name='prepaidnav']")
	private WebElement prepaidnav;

	@FindBy(css = "[name='middle']")
	private WebElement middle;

	@FindBy(css = "#continuel")
	private WebElement continueBtn;

	@FindBy(css = "tr")
	private List<WebElement> tr;

	@FindBy(css = ".headx")
	private WebElement header;

	public static final String okayPopUpTitle = "Intuition@POS";

	public POSEmailCapturePrepaid(WebDriver driver) {
		super(driver);
	}

	public POSEmailCapturePrepaid posValidation() {
		calContinue();
		testLease("Cash");
		amountValue();
		addTender();
		return this;
	}

	public POSEmailCapturePrepaid posSelectTenderType(String tenderType) {
		calContinue();
		testLease(tenderType);
		return this;
	}

	public POSEmailCapturePrepaid posAmountValueSelection() {
		amountValue();
		addTender();
		log("Entered " + amountValue + " clicked on Add Tender");
		return this;
	}

	public void calContinue() {
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, status);
		click(btnCalc);
		log("Clicked calculate and Continue");
	}

	public void testLease(String tenderType) {
		calContinue();
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, entryframe);
		Select selecttender = new Select(selectTender);
		selecttender.selectByVisibleText(tenderType);
	}

	public void amountValue() {
		getDriver().switchTo().defaultContent();
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, entryframe);
		amountValue.sendKeys(totalBalanceValue());
	}

	public String totalBalanceValue() {
		getDriver().switchTo().defaultContent();
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, entryframe);
		return totalBalanceDisplay.getText().replace("Balance:", "").replace(".", "").trim();
	}

	public void addTender() {
		getDriver().switchTo().defaultContent();
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, entryframe);
		waitAndClick(addBtn, 30);
		clickOkayPopUp();
		CommonUtils.sleep(10, TimeUnit.SECONDS); /*This is needed to support variant page load issue*/ 
		clickSkipBtn();
		closeDocument();
		closeAndContinue();
		//closeSecondDocument();
		storeMSISDN();
	}

	private void clickSkipBtn() {
		try {
			switchToParentWindow();
			waitAndClick(getDriver().findElement(By.cssSelector("input[value='Skip']")), 30);
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed account validation" + e.getMessage(), false);
			throw new RuntimeException(e);
		}
	}

	private void closeDocument() {
		switchToSecondWindow();
		switchFrame(frmL);
		waitAndClick(closeDocumentBtn, 30);
		switchToParentWindow();
	}

	private void closeAndContinue() {
		waitAndClick(closeBtn, 30);
		verifyCertificate();
		CommonUtils.sleep(5, TimeUnit.SECONDS);  /*This is needed to support variant page load issue*/ 
/*		if (isElementPresent(continueBtn)) {
		waitAndClick(continueBtn, 30);
		}*/
		}

	private void closeSecondDocument() {
		try {
			switchToSecondWindow();
			switchFrame(frmL);
			waitAndClick(closeDocumentBtn, 30);
			switchToParentWindow();
			waitAndClick(closeBtn, 30);
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed on second document close" + e, false);
		}
	}

	private void storeMSISDN() {
			switchFrame(middle);
			waitFor(header, 20);
			String number = null;
			for (WebElement webElement : tr) {
				if (webElement.getText().contains("PCS Phone Number")) {
					number = webElement.getText();
					switchToDefault();
					close();
					MatcherAssert.assertThat("Prepaid number: " + number + " is activated", true);
					break;
				};
				if	(webElement.getText().contains("Failure Reason")) {
					close();
					log("Activation failed");
					MatcherAssert.assertThat("Failed account validation and MSISDN not captured", false);
					break;
					}}}
				
	public void clickOkayPopUp() {
		if (getWindowByTitlePartial(okayPopUpTitle, 10)) {
			waitAndClick(okBtn, 30);
		}
	}

	private String parentWindow;

	public void getParentWindow() {
		getDriver().switchTo().window(parentWindow);
	}

	public String getParentWindowHandle() {
		return parentWindow;
	}

	public boolean getWindowByTitlePartial(String targetTitle, int waitTime) {
		for (int i = 0; i < waitTime; i++) {
			Set<String> handles = getDriver().getWindowHandles();
			for (String handle : handles) {
				if (!handle.equalsIgnoreCase(parentWindow)) {
					try {
						getDriver().switchTo().window(handle);
					} catch (UnhandledAlertException e) {
						getDriver().switchTo().window(handle);
					}
					String currentTitle = getDriver().getTitle();
					if (currentTitle.contains(targetTitle)) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
