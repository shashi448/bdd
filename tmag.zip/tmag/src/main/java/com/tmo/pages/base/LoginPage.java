package com.tmo.pages.base;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;

public class LoginPage extends BasePage {
	
	@FindBy(css="#username")
	private WebElement userName;
	
	@FindBy(css="#password")
	private WebElement password;
	
	@FindBy(css="#loginButton")
	private WebElement loginButton;
	
	@FindBy(css="#twotabsearchtextbox")
	private WebElement searchBox;
	
	@FindBy(css="[id*='issDi']")
	private WebElement results;
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}

/*    public HomePage doLogin() {
        setValue(searchBox, "iPhone7");
        return get(HomePage.class);
    }*/
    
    public LoginPage openAmazon() {
		try{
	        getDriver().get("https://www.amazon.com/");
		}catch (Exception e) {
		 log("openAmazon failed");
		 MatcherAssert.assertThat("openAmazon failed.", false);
		}
        return this;
    }
    
    public LoginPage doSearch() {
		try{
		    setValue(searchBox, "iPhone7");
		}catch (Exception e) {
		 log("doSearch failed");
		 MatcherAssert.assertThat("doSearch failed.", false);
		}
        return this;
    }
    
    public LoginPage results() {
		try{
	    	results.getSize();
		}catch (Exception e) {
		 log("results failed");
		 MatcherAssert.assertThat("results failed.", false);
		}
        return this;
    }
}
