
package com.tmo.pages.pos;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.tmo.tmag.base.Properties;
import com.tmobile.apptests.common.general.CommonUtils;

public class PosHomepage extends PosLoginPage{

	@FindBy(css="#sName")
	private WebElement storeNumber;

	@FindBy(css="#refAdmin")
	private WebElement adminLnk;

	@FindBy(css="#MainFrame")
	private WebElement mainFrame;

	@FindBy(css="input[value='Continue']")
	private WebElement continueBtn;

	@FindBy(css="#Logout")
	private WebElement logoutLnk;

	@FindBy(css="#MainFrame")
	private WebElement mainframeSwitch;
	
	@FindBy(css="#tStat")
	private WebElement tillStatus;
	
	@FindBy(css="#sStat")
	private WebElement storeStatus;
	
	public static String storeValue;

	public PosHomepage(WebDriver driver) {
		super(driver);
	}
	
	/**
	 * Method click's on Admin page if the Store is not open
	 * @param str - Store Number 
	 * @return Returns PosAdminPage
	 */
	public PosHomepage clickAdmin(String str) {
		try{
		log("POS store validation navigation started");	
		waitFor(storeNumber);
		log("Store Number"+storeNumber.getText()+" "+str+""+storeNumber.getText().contains(str));
			if (storeStatus.getText().contains("Closed") || tillStatus.getText().contains("Closed")
					|| storeNumber.getText().contains("279") || !storeNumber.getText().contains("451") || storeNumber.getText().contains((Properties.getURLProperty("oldStore")))) {
			waitAndClick(adminLnk, 10);
			CommonUtils.sleep(3, TimeUnit.SECONDS);
			if(verifyWindowPresenceByURL("ConfirmationDialog")){
				switchToWindowByURL("ConfirmationDialog");
				waitAndClick(continueBtn, 30);
				switchToWindowByURL("qatwspos");
			}
			getDriver().switchTo().defaultContent();
			new PosAdminPage(getDriver()).
			clickChangeStoreLocation().
			enterStoreId("451").
			validateStoreId();			
			if (isAlertPresent()) {
				getDriver().switchTo().alert().accept();
			}
			waitFor(storeNumber);
			storeValue = storeNumber.getText();
		} else {
			storeValue = storeNumber.getText();
		}
		}catch (Exception e) {
			log("POS store validation navigation  failed");
			MatcherAssert.assertThat("POS store validation navigation failed.", false);
		}
		return get(PosHomepage.class);
	}

	public PosHomepage clickOkPopUp() {
		Robot robot;
		try {
			log("POS popup validation started");
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_ENTER);
			switchToParentWindow();
		} catch (AWTException e) {
			log("POS popup validation failed");
			MatcherAssert.assertThat("POS popup validation failed.", false);
		}
		return this;
	}

	public void verifyStoreChanged(String str){
		getDriver().switchTo().frame(mainframeSwitch);
		if(storeNumber.getText().contains(str)){
			MatcherAssert.assertThat("Store Value Changed", true);
		}
		else
			MatcherAssert.assertThat("Store is same as previous after Change", false);
	}

}

