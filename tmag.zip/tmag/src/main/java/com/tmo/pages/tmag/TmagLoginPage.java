package com.tmo.pages.tmag;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;
import com.tmo.tmag.pages.TmagHomePage;

public class TmagLoginPage extends BasePage {

	@FindBy(css = ".pageLogo")
	private WebElement pageLogo;

	@FindBy(css = "#username")
	private WebElement username;

	@FindBy(css = "#password")
	private WebElement password;

	@FindBy(css = "#loginButton")
	private WebElement loginBtn;

	@FindBy(css = ".modalDialogButton")
	private WebElement passwordDailog;

	public TmagLoginPage(WebDriver driver) {
		super(driver);
	}

	public TmagLoginPage openTmag(String url) {
		try{
			log("Open TMAG application started");
			getDriver().get(url);
		}catch (Exception e) {
			log("Open TMAG application failed");
			MatcherAssert.assertThat("Open TMAG application failed.", false);
		}
		return this;
	}

	public TmagLoginPage navigateToTMag(String url) {
		try{
			log("TMAG URL navigation started");
			navigateTo(Properties.getURLProperty(System.getProperty("testEnv") + ".app.TMAG.url"));
			verifyCertificate();
		}catch (Exception e) {
			log("TMAG URL navigation  failed");
			MatcherAssert.assertThat("TMAG URL navigation failed.", false);
		}
		return this;
	}

	public TmagHomePage doLogin(String usertype) {
		try{
			log("TMAG login navigation started");
			waitFor(pageLogo, 60);
			setValue(username, Properties.getCredentialsProperty("tmag." + usertype + ".username"));
			setValue(password, Properties.getCredentialsProperty("tmag." + usertype + ".password"));
			setMacIDCookie("00059a3c7800", getDriver());
			click(loginBtn);
		}catch (Exception e) {
			log("TMAG login failed");
			MatcherAssert.assertThat("TMAG login failed.", false);
		}
		return get(TmagHomePage.class);
	}
}