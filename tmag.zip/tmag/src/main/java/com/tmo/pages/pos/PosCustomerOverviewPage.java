package com.tmo.pages.pos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.pages.TmagActivationConfirmationPage;

/**
 * POS Customer Overview page model object.
 * @author Prince
 *
 */
public class PosCustomerOverviewPage extends TmagActivationConfirmationPage {
	
	@FindBy(css="#ButtonCust1")
	private WebElement btnItemEntry;
	
	@FindBy(css="input[name='CustID'")
	private WebElement txtBan;
	
	@FindBy(css="input[name='CustMPhone']")
	private WebElement txtMsisdn;
	
	@FindBy(css="#MainFrame")
	private WebElement mainFrame;
	
	@FindBy(css="iFrame[name='Entry']")
	private WebElement entryFrame;
	
	@FindBy(css="iFrame[name='Status'")
	private WebElement statusFrame;
	
	

	public PosCustomerOverviewPage(WebDriver driver) {
		super(driver);
	}
	
	public PosCustomerOverviewPage acceptIngenicoNotConnnected() {
		verifyPageLoad("POS Ingenico Not Connected");
		if(isAlertPresent()) {
			acceptAlert();
		}
		return this;
	}
	
	public String getBan() {
		String ban;
		log("Switching to main frame then entry frame.");
		switchFrameInFrame(mainFrame, entryFrame);
		ban = txtBan.getText();
		switchToDefault();
		return ban;
	}
	
	public String getMSISDN() {
		String msisdn;
		log("Switching to main frame then entry frame.");
		switchFrameInFrame(mainFrame, entryFrame);
		msisdn = txtMsisdn.getText();
		switchToDefault();
		return msisdn;
	}
	
	public void continueCustomerInformation() {
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, statusFrame);
		click(btnItemEntry);
		log("Clicked Item Entry >> button");
	}
	
	
	
}
