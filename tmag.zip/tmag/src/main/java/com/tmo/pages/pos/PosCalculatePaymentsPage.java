package com.tmo.pages.pos;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PosCalculatePaymentsPage extends PosItemEntryPage {
	
	protected final Logger log = LoggerFactory.getLogger(PosCalculatePaymentsPage.class);
	
	@FindBy(css ="#ButtonCalcCont")
	private WebElement btnCalculateContinue;
	
	@FindBy(css="#payExtra")
	private WebElement txtFldAdditionalDownPayment;
	
	@FindBy(css="input[name='ButtonUpdate']")
	private WebElement btnUpdate;
	
	@FindBy(css="iframe[name='MainFrame']")
	private WebElement mainFrame;
	
	@FindBy(css="iframe[name='Status']")
	private WebElement statusFrame;

	@FindBy(css ="#ButtonCalc")
	private WebElement btnPrepaidContinue;

	public PosCalculatePaymentsPage(WebDriver driver) {
		super(driver);
	}
	
	public PosCalculatePaymentsPage enterDownPaymentAmount(String downPayment) {
		try {
		txtFldAdditionalDownPayment.clear();
		setValue(txtFldAdditionalDownPayment, downPayment);
		click(btnUpdate);
		} catch(Exception e) {
			log.error("Error in system use agreement",e);
			MatcherAssert.assertThat("Enter downpayment is failed", false);
		} 
		return this; 
	}
	
	public PosCalculatePaymentsPage clickPrepaidCalculateAndContinue() {
			try {
				switchFrame(mainFrame);
				WebElement ele = getDriver().findElement(By.cssSelector("iframe[src='ItemStatus.html']"));
				getDriver().switchTo().frame(ele);
				getDriver().findElement(By.cssSelector("#ButtonCalc")).click();
				switchToDefault();
		} catch(Exception e) {
			log.error("Error in system use agreement", e);
			MatcherAssert.assertThat("click PrepaidCalculate And Continue is failed", false);
		}
		return this;
	}

	public PosCalculatePaymentsPage calculatePaymentsAndContinue(String downPaymentAmount) {
			try {
				switchFrame(mainFrame);
				//getDriver().switchTo().frame("Header");
				WebElement ele = getDriver().findElement(By.cssSelector("iframe[src='CalculateWithInstallmentStatus.html']"));
				getDriver().switchTo().frame(ele);
				getDriver().findElement(By.cssSelector("#ButtonCalcCont")).click();
			switchToDefault();
			} catch(Exception e) {
			log.error("Error in system use agreement",e);
			MatcherAssert.assertThat("Click Calculateandcontinue button is failed", false);
		}
		return this;
	}
	
	

}
