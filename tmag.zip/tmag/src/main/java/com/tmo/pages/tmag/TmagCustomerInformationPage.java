package com.tmo.pages.tmag;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.pages.base.TmagConstants;

public class TmagCustomerInformationPage extends PrepaidMenuPage{
	//region
	@FindBy(css="select[name='market']")
	private WebElement custMarket;

	@FindBy(css="input[name='birthdate']")
	private WebElement txtDOB;

	@FindBy(css="input[name='j_password'][type='password']")
	private WebElement txtPIN;

	@FindBy(css="#f_Name")
	private WebElement txtFirstName;

	@FindBy(css="#l_Name")
	private WebElement txtLastName;

	@FindBy(css="input[name='welcomeEmail'][class='iopt']")
	private WebElement txtWelcomeEmail;

	@FindBy(css="frame[name='prepaidnav']")
	private WebElement frameprenav;

	@FindBy(css="input[name='nextButton']")
	private WebElement btnNext;
	
	@FindBy(css="frame[name='middle']")
	private WebElement middleFrame;

	@FindBy(id="numMBBServReq")
	private WebElement cmbbLines;
	
	@FindBy(id="ratePlanType")
	private WebElement cmbRatePlanType;
	
	
	@FindBy(id="numServReq")
	private WebElement cmbVoiceLines;
	
	public TmagCustomerInformationPage(WebDriver driver) {
		super(driver);
	}

	public TmagRatePlanFeatures customerInformation(String customerMarket, String birthDate, String pin) {
		try {
			switchFrame(middleFrame);
			waitFor(txtPIN);
			waitFor(txtDOB);
			waitFor(custMarket);
			setValue(custMarket, customerMarket);
			setValue(txtDOB, birthDate);
			setValue(txtPIN, pin);
			getDriver().switchTo().defaultContent();
			nextButtonClk();
			log("Customer Information Next Button: Click");
		}
		catch (Exception e) {
			MatcherAssert.assertThat("Customer Information Next Button Click - Fail", false);
			close();
			throw new RuntimeException(e);
		}
		return get(TmagRatePlanFeatures.class);
	}
	public TmagRatePlanFeatures nextButtonClk() {
		try {		
		switchFrame(frameprenav);
		waitAndClick(btnNext, 60);
			}
		
	catch (Exception e) {
		MatcherAssert.assertThat("Customer Information Next Button Click - Fail", false);
		close();
		throw new RuntimeException(e);
	}
		return get(TmagRatePlanFeatures.class);
}
	
	public TmagRatePlanFeatures checkVoiceDataAndClick(String scenario) {
		if(TmagConstants.SCN_AAMBIRNonPooledEIPPRMArket.equals(scenario)) {
			setMarket("Puerto Rico");
		}
		
		waitAndClick(btnNext, 60);
		return get(TmagRatePlanFeatures.class);
	}
	
	public void setMarket(String marketStr) {
		setValue(custMarket, marketStr);
	}
}