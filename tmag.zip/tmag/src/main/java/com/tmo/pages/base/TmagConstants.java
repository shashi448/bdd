package com.tmo.pages.base;

public class TmagConstants {
	
	private TmagConstants() {
		
	}
	
	public static final String SCN_AAGSMIRNonPooledEIP = "AAGSMIRNonPooledEIP";
	
	public static final String SCN_AAGSMIRPooledFRP = "AAGSMIRPooledFRP";
	
	public static final String SCN_AAMBIRNonPooledEIP = "AAMBIRNonPooledEIP";
	
	public static final String SCN_AAMBIRNonPooledEIPPRMArket = "AAMBIRNonPooledEIPPRMArket";
	
	public static final String SCN_AAGSMEIPDRP = "AAGSMEIPDRP";
	
	public static final String Single_Voice_line = "Selected 1 additional voice line";
	
	public static final String Single_Data_line = "Selected 1 additional data line";
	
	public static final String Non_Pooled = "Non Pooled";
	
	public static final String EIP_Pricing = "EIP pricing";
	
	public static final String New_Device = "New Device";

}
