package com.tmo.pages.pos;

import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;

public class PosCustomerInformation extends BasePage {

	@FindBy(css="#MainFrame")
	private WebElement mainFrame;

	@FindBy(css="iframe[name='Status']")
	private WebElement status;
	
	@FindBy(css="#ButtonCust1")
	private WebElement itemEntry;

	public PosCustomerInformation(WebDriver driver) {
		super(driver);
	}

	public POSEmailCapturePrepaid getItemEntry() {
		try{
			log("Switching to main frame then status frame.");
			switchFrameInFrame(mainFrame, status);
			click(itemEntry);
			log("Clicked Item Entry >> button");
			if(isAlertPresent()){
				getDriver().switchTo().alert().accept();
			}
		}
		catch (UnhandledAlertException e){
			log("Item Entry : Pass");
			try {
				getDriver().switchTo().alert().accept();
			} 
			catch (Exception ex)
			{}
		}
		return get(POSEmailCapturePrepaid.class);
	}
}	
