package com.tmo.pages.pos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PosValidateEmailCapturePage extends PosAddTenderPage {

	@FindBy(css="input[value='Skip'][type='button']")
	private WebElement btnSkip;
	
	@FindBy(css = "input[id='continuel'][type='button'][value='Continue']")
	private WebElement btnContinue;
	
	public PosValidateEmailCapturePage(WebDriver driver) {
		super(driver);
	}
	
	public PosValidateEmailCapturePage skipAndContinue() {
		click(btnSkip);
		return this;
	}

	
}
