package com.tmo.pages.tmag;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TmagRatePlanFeatures extends TmagCustomerInformationPage {
	
	protected String env = System.getProperty("testEnv");

	@FindBy(css = "frame[name='middle']")
	private WebElement framemiddle;

	@FindBy(css = "input[name='sim'][type='text']")
	private WebElement txtSIM;

	@FindBy(css = "input[name='imei'][type='text']")
	private WebElement txtIMEI;

	@FindBy(css = "#validateButton")
	private WebElement btnValidate;

	@FindBy(css = "#PAY_GO")
	private WebElement payGo;

	public TmagRatePlanFeatures(WebDriver driver) {
		super(driver);
	}

	public TmagRatePlanFeatures ratePlanFeatures() {
		String imei = "";
		try {
			switchFrame(framemiddle);
			String strSim = getSim(env);
			try { setValue(txtSIM, strSim);
			} catch (Exception e) {
				MatcherAssert.assertThat("Rate Plan & Device: Enter SIM", false);
				throw new RuntimeException(e);
			}
			String imeiScript = "function imei_gen() {" + "var pos;"
					+ "var str = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);" + "var sum = 0;"
					+ "var final_digit = 0;" + "var t = 0;" + "var len_offset = 0;" + "var len = 15;" + "var issuer;" + ""
					+ "var rbi = [\"01\",\"10\",\"30\",\"33\",\"35\",\"44\",\"45\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"86\",\"91\",\"98\",\"99\"];"
					+ "var arr = rbi[Math.floor(Math.random() * rbi.length)].split(\"\");" + "str[0] = Number(arr[0]);"
					+ "str[1] = Number(arr[1]);" + "pos = 2;" + "while (pos < len - 1) {"
					+ "str[pos++] = Math.floor(Math.random() * 10) % 10;" + "}" + "" + "len_offset = (len + 1) % 2;"
					+ "for (pos = 0; pos < len - 1; pos++) {" + "if ((pos + len_offset) % 2) {" + "t = str[pos] * 2;"
					+ "if (t > 9) {" + "t -= 9;" + "}" + "sum += t;" + "}" + " else {" + "sum += str[pos];" + "}" + "}" + ""
					+ "final_digit = (10 - (sum % 10)) % 10;" + "str[len - 1] = final_digit;" + "t = str.join('');"
					+ "t = t.substr(0, len);" + "return t;" + "		}; return imei_gen();";
			imei = (String) ((JavascriptExecutor) getDriver()).executeScript(imeiScript);
			setValue(txtIMEI, imei);
			waitAndClick(btnValidate, 60);
			log("Btn Validate: Click");
		} catch (Exception e) {
			MatcherAssert.assertThat("Rate Plan Featres Next Button: Click", false);
			close();
			throw new RuntimeException(e);
		}

		return this;
	}
	
	public TmagWifiCallingPage payAsYouGo(String paygooption){
		waitFor(payGo);
		payGo.click();
		log("Clicked on "+paygooption);
		nextButtonClk();
		return get(TmagWifiCallingPage.class);
	}
}
