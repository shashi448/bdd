
package com.tmo.pages.pos;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PosAdminPage extends PosHomepage {

	@FindBy(css = "#MainFrame")
	private WebElement mainFrame;

	@FindBy(css = "a[target='MainFrame']")
	private List<WebElement> changeStoreLocation;

	@FindBy(css = "#StoreID")
	private WebElement txtStoreId;

	@FindBy(css = "input[value='Continue']")
	private WebElement continueButton;

	@FindBy(css = "input[value='yes']")
	private WebElement clickYesButton;

	public PosAdminPage(WebDriver driver) {
		super(driver);
	}

	public PosAdminPage clickChangeStoreLocation() {
		getDriver().switchTo().defaultContent();
		switchFrame(mainFrame);
		for (WebElement webElement : changeStoreLocation) {
			if(webElement.getText().contains("Change Store Location")) {
				waitAndClick(webElement, 20);
				break;
			}
		}
		return this;
	}

	public PosAdminPage enterStoreId(String storeId) {
		waitFor(txtStoreId);
		txtStoreId.click();
		txtStoreId.clear();
		txtStoreId.sendKeys(storeId);
		continueButton.click();
		return this;
	}

	public PosAdminPage validateStoreId() {
		try {
		    verifyWindowPresenceByURL("storeValidate");
			waitAndClick(clickYesButton, 30);
			verifyWindowPresenceByURL("storeValidate");
			Robot robot;
			try {
				robot = new Robot();
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);


				robot.keyPress(KeyEvent.VK_ENTER);
				robot.keyPress(KeyEvent.VK_ENTER);
				switchToParentWindow();

			} catch (AWTException e) {
				log.error("Error in system use agreement",e);
			}
			if (isAlertPresent()) {
				getDriver().switchTo().alert().accept();
			}
		} catch (UnhandledAlertException e) {
			
		}
		return this;
	}
	
	public PosHomepage clickOkPopUp() {
		Robot robot;
		try {
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyPress(KeyEvent.VK_ENTER);
			switchToParentWindow();

		} catch (AWTException e) {
			log.error("Error in system use agreement",e);
		}
		try {
			 switchToWindowByURL("qatwspos");
		} catch (UnhandledAlertException ex) {
			getDriver().findElement(By.tagName("body")).click();
			getDriver().findElement(By.tagName("body")).sendKeys(Keys.ENTER);
		}
		return this;
	}

}
