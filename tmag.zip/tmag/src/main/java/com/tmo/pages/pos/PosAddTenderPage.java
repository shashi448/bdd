package com.tmo.pages.pos;

import java.util.concurrent.TimeUnit;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.Properties;
import com.tmobile.apptests.common.general.CommonUtils;

public class PosAddTenderPage extends PosCalculatePaymentsPage {

	@FindBy(css = "#TenderAmt")
	private WebElement txtFldTenderAmount;

	@FindBy(css = "#totalDisplay")
	private WebElement lblBalance;

	@FindBy(css = "#tenderButton")
	public WebElement btnAddTender;

	@FindBy(css = "#TenderType")
	public WebElement selTenderType;

	@FindBy(css = "select[id='TenderType']option[value='0']")
	private WebElement lblCashTenderType;

	@FindBy(css = "iframe[name='MainFrame']")
	private WebElement mainFrame;

	@FindBy(css = "iframe[name='Entry']")
	private WebElement entry;

	public PosAddTenderPage(WebDriver driver) {
		super(driver);
	}

	private String convertBalance(String balance) {
		return balance.replace("Balance: ", "");
	}

	public void addTender() {
		try {
			switchFrame(mainFrame);
			WebElement ele = getDriver().findElement(By.cssSelector("iframe[src='TenderEntryVesta.jsp']"));
			getDriver().switchTo().frame(ele);
			String balanceVal = getDriver().findElement(By.cssSelector("#totalDisplay")).getText();
			balanceVal = balanceVal.substring(9);
			balanceVal = balanceVal.replace(".", "");
			setValue(getDriver().findElement(By.cssSelector("#TenderAmt")), convertBalance(balanceVal));
			getDriver().findElement(By.cssSelector("#tenderButton")).click();
			switchToDefault();
			log("Balance paid");
		} catch (Exception e) {
			log.error("Error in system use agreement" + e);
			MatcherAssert.assertThat("Add tender amount failed.", false);
		}
	}

	public void handlePopups() {
		try {
			acceptAlert();
			acceptAlert();
			switchToSecondWindow();
			getDriver().close();
			CommonUtils.sleep(2, TimeUnit.SECONDS);  /*This is needed to support variant page load issue*/ 
			switchToSecondWindow();
			close();
		} catch (Exception e) {
			log.error("Error in system use agreement" + e);
			 MatcherAssert.assertThat("Customer payment balance as zero pop-up failed", false);
		}
	}

	public void selTenderType() {
		try {
			switchFrame(mainFrame);
			WebElement ele = getDriver().findElement(By.cssSelector("iframe[src='TenderEntryVesta.jsp']"));
			getDriver().switchTo().frame(ele);
			setValue(getDriver().findElement(By.cssSelector("#TenderType")),
					Properties.getUserProperty("Tendermethod"));
			switchToDefault();
		} catch (Exception e) {
			log.error("Error in system use agreement" + e);
			MatcherAssert.assertThat("Select tender type as Cash failed", false);
		}
	}

}
