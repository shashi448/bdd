package com.tmo.pages.pos;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * POS Item Entry page object model.
 * @author Prince
 *
 */
public class PosItemEntryPage extends PosCustomerOverviewPage {
	
	@FindBy(css="#ButtonInstlCalc")
	private WebElement btnCalculateWithPayments;
	
	@FindBy(css="#ButtonDRP")
	private WebElement btnDeviceTradeIn;
	
	@FindBy(css="select[id='select']")
	private WebElement lblDoesNotHaveDevice;
	
	@FindBy(css="#MainFrame")
	private WebElement mainFrame;
	
	@FindBy(css="iframe[name='Status']")
	private WebElement statusFrame;
	

	public PosItemEntryPage(WebDriver driver) {
		super(driver);
	}
	
	public PosItemEntryPage continueCalculateWithPayments() {
		verifyPageLoad("POS Cart");	
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, statusFrame);
		
		if (!btnCalculateWithPayments.isEnabled()) {
			click(btnDeviceTradeIn);
			log("Clicked on Device Trade In.");
			switchToSecondWindow();
			waitForPageToLoad();
			log("Switched to DRP Popup");
			//NoSuchWindowException: Unable to find element on closed window
			selectByText(lblDoesNotHaveDevice, "Does not have a device");
			log("Selected Does not have a device.");
			//help
			//switchToDefault();
			log("Switched back to main window.");
			switchToParentWindow();
			switchFrameInFrame(mainFrame, statusFrame);
			click(btnCalculateWithPayments);
			log("Clicked on Calculate with Payments button.");
		}
		else {
			click(btnCalculateWithPayments);
			log("Clicked on Calculate with Payments button.");
		}
		switchToDefault();
		return this;
	}
	
	public PosItemEntryPage acceptDRP() {
		verifyPageLoad("POS Cart");	
		log("Switching to main frame then status frame.");
		switchFrameInFrame(mainFrame, statusFrame);
		
		if (!btnCalculateWithPayments.isEnabled()) {
			click(btnDeviceTradeIn);
			log("Clicked on Device Trade In.");
			switchToSecondWindow();
			waitForPageToLoad();
			log("Switched to DRP Popup");
			//NoSuchWindowException: Unable to find element on closed window
			selectByText(lblDoesNotHaveDevice, "Does not have a device");
			log("Selected Does not have a device.");
			//help
			//switchToDefault();
			log("Switched back to main window.");
			switchToParentWindow();
			switchFrameInFrame(mainFrame, statusFrame);
			click(btnCalculateWithPayments);
			log("Clicked on Calculate with Payments button.");
		}
		else {
			click(btnCalculateWithPayments);
			log("Clicked on Calculate with Payments button.");
		}
		switchToDefault();
		return this;
	}
	

}
