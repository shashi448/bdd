package com.tmo.pages.pos;


import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;

public class PosLoginPage extends BasePage {

	@FindBy(name = "username")
	private WebElement username;

	@FindBy(name = "password")
	private WebElement password;

	@FindBy(css = "input[type='submit']")
	private WebElement submitBtn;

	@FindBy(css="#MainFrame")
	private WebElement mainframeSwitch;

	public PosLoginPage(WebDriver driver) {
		super(driver);		
	}

	public PosLoginPage openPOS(String url) {
		getDriver().get(url);
		return this;
	}

	public PosHomepage doLogin(String usertype) {
		try{
			log("POS page credential login started");
			verifyCertificate();
			if(usertype.contentEquals("POS")) {
				waitFor(username);
				setValue(username, Properties.getCredentialsProperty("tmag.POS.username"));
				setValue(password, Properties.getCredentialsProperty("tmag.POS.password"));
			}
				setMacIDCookie("00059a3c7800",getDriver());
				submitBtn.click();
				if (isAlertPresent()) {
					acceptAlert();
				}
				getDriver().findElement(By.tagName("body")).click();
				getDriver().findElement(By.tagName("body")).sendKeys(Keys.ENTER);
		}catch (Exception e) {
			log("POS page credential login  failed");
			MatcherAssert.assertThat("POS page credential login failed.", false);
		}
		getDriver().switchTo().frame(mainframeSwitch);
		return get(PosHomepage.class);
	}		
}

