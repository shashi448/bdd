package com.tmo.pages.pos;

import java.util.List;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;

public class DeviceTradeInQuoteTool extends BasePage {

	@FindBy(css = "#quoteToolFrame")
	private WebElement toolFrame;

	@FindBy(css = "#drpQuoteToolContainer")
	private WebElement quoteFrame;

	@FindBy(css = "input[name='serialNumberInput'][type='text']")
	private WebElement imeiTxt;

	@FindBy(css = "button[type='submit']")
	private WebElement checkBtn;

	@FindBy(css = "div[class='ember-view device-dropdown'] span:nth-child(1) select")
	private WebElement deviceCarrierDDL;

	@FindBy(css = "div[class='ember-view device-dropdown'] span:nth-child(2) select")
	private WebElement deviceMakeDDL;

	@FindBy(css = "div[class='ember-view device-dropdown'] span:nth-child(3) select")
	private WebElement deviceModelType;

	@FindBy(css = "input[class='ember-view ember-radio-button']")
	private List<WebElement> deviceQuestionaire;

	@FindBy(css = "input[class='ember-view ember-radio-button']")
	private List<WebElement> questionnaireRadioBtns;

	@FindBy(css = "button[data-ember-action]")
	private List<WebElement> allButtons;

	@FindBy(css = "div[class='ember-view quote-list-item ui-draggable']")
	private WebElement phoneToDrag;

	@FindBy(css = ".instant-defer-container")
	private WebElement targetToDrop;

	@FindBy(css = "button:contains('Continue')")
	private WebElement continueBtn;

	@FindBy(css = "div[class='modalDialogTitle']")
	private WebElement quoteToolHeader;

	public DeviceTradeInQuoteTool(WebDriver webDriver) {
		super(webDriver);
	}

	public DeviceTradeInQuoteTool verifyActivationInfoPg() {
		try {
			log("Verifying - Quote Tool Info Pg: Landing Page");
			MatcherAssert.assertThat("Quote Tool Info Pg: ", isElementPresent(quoteToolHeader));
			log("Verfied -Quote Tool Info Pg: Landing Page");
		} catch (Exception e) {
			log("Quote Tool Info Pg: Landing Page verification failed");
			MatcherAssert.assertThat("verifyActivationInfoPg failed.", false);
		}
		return this;
	}

	public DeviceTradeInQuoteTool checkIMEI() {
		try {
			log("Check IMEI page action started");
			waitForPageToLoad();
			if (isAlertPresent())
				log("Checking for Spinner to loader");
			switchFrame(toolFrame);
			if (isAlertPresent())
				log("Spinner");
			waitFor(checkBtn, 30);
			waitFor(imeiTxt, 60);
			if (isAlertPresent())
				log("Spinner Checking");

			String resultIMEI = getIMEINumber();
			log("IMEI Generated: " + resultIMEI);
			setValue(imeiTxt, resultIMEI);
			waitAndClick(checkBtn, 30);
			if (isAlertPresent()) {
				log("Checking Spinner");
			}
			waitFor(deviceModelType, 30);
			setValue(deviceCarrierDDL, Properties.getUserProperty("qlab02.tap.devicecarrier"));
			setValue(deviceMakeDDL, Properties.getUserProperty("qlab02.tap.devicemake"));
			setValue(deviceModelType, Properties.getUserProperty("qlab02.tap.devicetype"));
			switchToDefault();
		} catch (Exception e) {
			log("IMEI Validation failed");
			MatcherAssert.assertThat("checkIMEI failed.", false);
		}
		return this;
	}

	public DeviceTradeInQuoteTool chooseAnswersAsYes() {
		try {
			switchToDefault();
			if (isAlertPresent()) {
				log("Checking for Spinner");
			}
			waitFor(toolFrame, 60);
			switchFrame(toolFrame);
			log("Radio Btn: " + questionnaireRadioBtns.size());
			for (int i = 0; i < questionnaireRadioBtns.size(); i++) {
				click(questionnaireRadioBtns.get(i));
			}
			log("Get Quote: " + allButtons.size());
			for (WebElement webElement : allButtons) {
				if (webElement.getText().contains("Get Quote")) {
					webElement.click();
					break;
				}
			}
		} catch (Exception e) {
			log("DRP action failed");
			MatcherAssert.assertThat("chooseAnswersAsYes failed.", false);
		}
		return this;
	}

	public DeviceTradeInQuoteTool dragAndDropDevice() {
		try {
			waitFor(phoneToDrag, 60);
			if (isAlertPresent()) {
				log("Checking for Spinner");
			}
			if (isElementPresent(phoneToDrag)) {
				new Actions(getDriver()).clickAndHold(phoneToDrag).moveToElement(targetToDrop).release(targetToDrop)
						.build().perform();
			}
		} catch (Exception e) {
			log("DRP action drag and drop failed");
			MatcherAssert.assertThat("dragAndDropDevice failed.", false);
		}
		return this;
	}
}