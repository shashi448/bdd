package com.tmo.pages.tmag;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.tmo.tmag.pages.TmagHomePage;

public class PrepaidMenuPage extends TmagHomePage{
	
	@FindBy(css = "frame[name='middle']")
	private WebElement frameMiddle;
	
	@FindBy(css = "#Out1t")
	private WebElement prepaidPhone;

	public PrepaidMenuPage(WebDriver driver) {
		super(driver);
	}

	public TmagCustomerInformationPage clickPrepaidPhone() {
		try{
			log("Prepaid phone selection click started");
			waitFor(frameMiddle, 30);
			switchFrame(frameMiddle);
			waitAndClick(prepaidPhone, 30);
			log("Click performed on element: " + prepaidPhone);
			
		}catch (Exception e) {
			log("Prepaid phone selection click failed");
			MatcherAssert.assertThat("clickPrepaidPhone failed.", false);
		}
		return get(TmagCustomerInformationPage.class);
	}
}
