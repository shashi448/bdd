package com.tmo.tesa.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thoughtworks.selenium.webdriven.commands.WindowFocus;
import com.thoughtworks.selenium.webdriven.commands.WindowMaximize;
import com.tmo.tmag.base.BasePage;
import com.tmo.tmag.base.Properties;

public class TesaIngenicoPrintDocumentPage extends TesaEmailValidatePage {

	@FindBy(css = "input[value='Close'], input[value='Continue']")
	private WebElement btnClose;

	@FindBy(css = "input[value='Close'], input[value='Continue']")
	private WebElement btnFinish;

	@FindBy(css = "input[id='end-of-document-btn-finish'][class='documents-finish-button btn btn-main btn-lg']")
	private WebElement btnDocFinish;
	
	@FindBy(css = "button[id='action-bar-btn-finish']")
	private WebElement btnNavigateFinish;

	@FindBy(css = "input[class='tab-form-element main-radio-tab-input']")
	private WebElement btnSignTermsAndCondition;

	@FindBy(css = "input[id='navigate-btn'][tabindex='-1']")
	private WebElement btnNavigate;

	@FindBy(css = "svg[class='tab-image tab-image-for-signature']")
	private WebElement btnSign;

	public TesaIngenicoPrintDocumentPage(WebDriver driver) {
		super(driver);
	}

	public TesaIngenicoPrintDocumentPage closeAndContinue() {
		verifyPageLoad("TESA Ingenico Print Document");
		log("Close button: " + isElementPresent(btnClose));
		btnClose.sendKeys(Keys.ENTER);
		return this;
	}

	public TesaIngenicoPrintDocumentPage signDocumentVerifyAndFinish() {
		try {
			log("signDocumentVerifyAndFinish start.");
			switchToSecondWindow();
			waitAndClick(btnNavigateFinish, 50);
			waitAndClick(btnSignTermsAndCondition, 30);
			waitAndClick(btnNavigateFinish, 30);
			waitAndClick(btnNavigateFinish, 30);
			waitAndClick(btnSign, 30);
			waitAndClick(btnNavigateFinish, 30);
			switchToSecondWindow();
			close();
			switchToParentWindow();
		} catch (Exception e) {
			log.error("Sign Document verify and Finish" + e);
			MatcherAssert.assertThat("Documentation sign action failed", false);
		}
		return this;
	}
}
