package com.tmo.tesa.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TesaFinalConfirmationPage extends TesaEmailValidatePage {

	@FindBy(css = "input[value='Close'][type='button']")
	private WebElement btnClose;

	@FindBy(css = "div[id='billingActNo']")
	private WebElement txtAccountNumber;

	@FindBy(css = "table[class='stdTable summaryTable']>tbody>tr>td[1]")
	private WebElement tblSummary;

	@FindBy(css = "table[id='lineDetails']")
	private WebElement tblSummaryMsisdn;

	private static final String STR_ACTIVATION_SUCCESS = "Activation Scenario Successful!";

	public TesaFinalConfirmationPage(WebDriver driver) {
		super(driver);
	}

	public void isActivationSuccessful(String ban, String msisdn) {
		try {
			log("Activation validation started.");
			if ((getDriver().getPageSource().contains("The document has been created and stored successfully "))
					|| (getDriver().getPageSource().contains("Activation completed."))) {
				if (getDriver().getPageSource().contains("The document has been created and stored successfully ")) {
					click(btnClose);
					log(STR_ACTIVATION_SUCCESS);
					log("BAN:    " + ban);
					log("MSISDN: " + msisdn);
					assertMatcher(STR_ACTIVATION_SUCCESS, true);
				} else {
					ban = txtAccountNumber.getText();
					msisdn = driver.findElement(By.xpath("//table/tbody/tr/td[2]")).getText();
					log(STR_ACTIVATION_SUCCESS);
					log("BAN:    " + ban);
					log("MSISDN: " + msisdn);
					close();
					assertMatcher(STR_ACTIVATION_SUCCESS, true);
				}
			} else {
				log("Activation Failed.");
				assertMatcher("Activation Scenario Failure!", false);
			}
		} catch (Exception e) {
			log("Activation Scenario Failed");
			MatcherAssert.assertThat("Activation Scenario Failed.", false);
		}
	}

	public void isCstActivationSuccessful(String ban, String msisdn) {
		try {
			log("Activation validation started.");
			if (getDriver().getPageSource().contains("Activation completed.")) {
				ban = txtAccountNumber.getText();
				msisdn = driver.findElement(By.xpath("//table/tbody/tr/td[2]")).getText();
				log(STR_ACTIVATION_SUCCESS);
				log("BAN:    " + ban);
				log("MSISDN: " + msisdn);
				close();
				assertMatcher(STR_ACTIVATION_SUCCESS, true);
			} else {
				log("Activation Failed.");
				assertMatcher("Activation Scenario Failure!", false);
			}
		} catch (Exception e) {
			log("Activation Failed.");
			MatcherAssert.assertThat("isCstActivationSuccessful failed.", false);
		}
	}

	public void isPostpaidActivationSuccessful(String ban, String msisdn) {
		try{
			log("Activation validation started.");
			if (getDriver().getPageSource().contains("Activation completed.")) {
				ban = txtAccountNumber.getText();
				msisdn = driver.findElement(By.xpath("//table/tbody/tr/td[2]")).getText();
				log("Activation completed, payment pending");
				log("BAN:    " + ban);
				log("MSISDN: " + msisdn);
				assertMatcher("Activation completed, payment pending", true);
			} else {
				log("Activation Failed.");
				assertMatcher("Activation Scenario Failure!", false);
			}
		}catch (Exception e) {
			log("Activation Failed.");
			 MatcherAssert.assertThat("isCstActivationSuccessful failed.", false);
		}
	}

}
