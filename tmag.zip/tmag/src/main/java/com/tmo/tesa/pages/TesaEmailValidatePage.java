package com.tmo.tesa.pages;

import org.hamcrest.MatcherAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.tmo.tmag.base.Properties;
import com.tmo.tmag.pages.TmagActivationSummaryResultsPage;

/**
 * TESA Email validation page object model.
 * @author Prince
 *
 */
public class TesaEmailValidatePage extends TmagActivationSummaryResultsPage {
	
	@FindBy(css = "#continuel")
	private WebElement btnContinue;
	
	@FindBy(css = "input[value='Skip'][id='skipl']")
	private WebElement btnSkip;
	
	@FindBy(css = "input[value='Continue'][id='quoteTool']")
	private WebElement btnCostcoContinue;

	public TesaEmailValidatePage(WebDriver driver) {
		super(driver);
	}
	
	public TesaEmailValidatePage validateContinueEmail() {
		try{
			log("Tesa email validation click continue email started");
			click(btnContinue);
		}catch (Exception e) {
		 log("Tesa email validation click continue email failed.");
		 MatcherAssert.assertThat("validateContinueEmail failed.", false);
		}
		return this;
	}
	
	public TesaEmailValidatePage validateCostcoContinueEmail() {
		try{
			log("Tesa email validation click continue email started");
			click(btnCostcoContinue);
		}catch (Exception e) {
		 log("Tesa email validation click continue email failed.");
		 MatcherAssert.assertThat("validateContinueEmail failed.", false);
		}
		return this;
	}
	
	public TesaEmailValidatePage skipAndContinue() {
		try{
			log("Tesa email skip and continue started");
			waitAndClick(btnSkip, 20);
		}catch (Exception e) {
		 log("Tesa email skip and continue failed.");
		 MatcherAssert.assertThat("skipAndContinue failed.", false);
		}
		return this;
	}

	public TesaEmailValidatePage skipAndCompleteAct() {
		try{
			log("Tesa skip and complete activation started");
			switchToParentWindow();
			close();
			getDriver().quit();
		}catch (Exception e) {
		 log("Tesa skip and complete activation failed.");
		 MatcherAssert.assertThat("skipAndCompleteAct failed.", false);
		}
		return this;
	}
	
	public TesaEmailValidatePage closeReceipt() {
		try{
			log("Tesa close receipt started");
			switchToSecondWindow(); //receipt window
			close();
		}catch (Exception e) {
		 log("Tesa close receipt failed.");
		 MatcherAssert.assertThat("TESA closeReceipt failed.", false);
		}
		return this;
	}
}
