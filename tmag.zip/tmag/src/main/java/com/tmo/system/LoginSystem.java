package com.tmo.system;

import org.hamcrest.MatcherAssert;
import org.mortbay.log.Log;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.tmo.pages.base.LoginPage;
import com.tmo.pages.pos.POSEmailCapturePrepaid;
import com.tmo.pages.pos.PosCustomerInformation;
import com.tmo.pages.pos.PosLoginPage;
import com.tmo.pages.tmag.PrepaidMenuPage;
import com.tmo.pages.tmag.TmagCustomerInformationPage;
import com.tmo.pages.tmag.TmagLoginPage;
import com.tmo.pages.tmag.TmagRatePlanFeatures;
import com.tmo.pages.tmag.TmagWifiCallingPage;
import com.tmo.tmag.base.BaseSystem;
import com.tmo.tmag.base.Properties;
import com.tmo.tmag.pages.TmagHomePage;
import com.tmo.tmag.pages.TmagServiceSetup;

public class LoginSystem extends BaseSystem {

	protected String env = System.getProperty("testEnv");

	public LoginSystem(WebDriver webDriver) {
		super(webDriver);
	}

	private LoginPage login;
	private TmagLoginPage tmagLogin;
	private PosLoginPage posLogin;
	private PosCustomerInformation posCustomer;
	private TmagHomePage tmagHomePage;
	private TmagCustomerInformationPage tmagCustomerInfo;
	private String errormsg = " is not visible within 60 seconds.";

	public void tmagLoginAndPrepaid(String arg1) {
		tmagLogin = new TmagLoginPage(driver);
		try {
			log("TMAG URL navigation & login started");
			tmagLogin.navigateToTMag(arg1);
			tmagLogin.doLogin(arg1);
		} catch (Exception e) {
			log("TMAG URL navigation & login failed");
			MatcherAssert.assertThat("TMAG URL navigation & login failed" + tmagLogin + errormsg, false);
		}
	}

	public void tmagLogin(String arg1) {
		try {
			log("TMAG login started");
			tmagLogin = new TmagLoginPage(driver);
		} catch (NoSuchElementException e) {
			log("tmag Login failed");
			MatcherAssert.assertThat("tmag login failed", false);
		}
	}

	public void validateStoreAndTill() {
		tmagHomePage = new TmagHomePage(driver);
		try {
			log("TMAG home page - Till and store validation started");			
			tmagHomePage.validateStoreAndTill();
		} catch (NoSuchElementException e) {
			log("TMAG home page - Till and store validation failed");	
			MatcherAssert.assertThat("Failure while opening TMAG store and till.", false);
		}
	}

	public void log(String str) {
		login.log(str);
	}
	
	public void posLogin(String arg1) {
		try{
			log("POS URL opening navigation started");
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.get(Properties.getURLProperty(System.getProperty("testEnv") + ".app.POS.url"));
			posLogin = new PosLoginPage(driver);
			posLogin.doLogin("POS").clickAdmin(Properties.getURLProperty("oldStore"));
		}catch (Exception e) {
			log("POS Login failed");
			MatcherAssert.assertThat("POS Login failed.", false);
		}
	}

	public void posCustomerInformationSteps() {
		posCustomer = new PosCustomerInformation(driver);
		try {
			new POSEmailCapturePrepaid(driver).posValidation();
		} catch (Exception e) {
			MatcherAssert.assertThat("Pos Customer Information Failure", false);
			Log.info("POS Customer infromation failure");
			new RuntimeException(e);
		}
	}

	public void customerInformation(String args1, String args2, String args3) {
		try {
			tmagCustomerInfo = new TmagCustomerInformationPage(driver);
			tmagCustomerInfo.customerInformation(args1, args2, args3);
		} catch (NoSuchElementException e) {
			MatcherAssert.assertThat(errormsg, false);
		}
	}

	public void simandimeiInformation() {
		try {
			new TmagWifiCallingPage(driver).ratePlanFeatures();
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed on SIM and IMEI Information Page", false);
			throw new RuntimeException(e);
		}
	}

	public void payasyouGo(String payasYouGo) {
		try {
			new TmagRatePlanFeatures(driver).payAsYouGo(payasYouGo);
			new TmagWifiCallingPage(driver).E911AddressPrepaid();
		} catch (Exception e) {
			log("Failed at Pay As You Go - MSISDN or IMEI failure");
			MatcherAssert.assertThat("Failed at Pay As You Go - MSISDN or IMEI failure", false);
		}
	}

	public void prepaidselectionService(String prepaidSelection) {
		try {
			new TmagServiceSetup(driver).prepaidServiceSelection(prepaidSelection);
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed at Prepaid Selection Service" + e.getMessage(), false);
		}
	}

	public void areaCode(String areaCode) {
		try {
			new TmagServiceSetup(driver).AreaCode(areaCode);
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed at Area Code Selection Service" + e.getMessage(), false);
		}
	}

	public void langSelection(String language) {
		try {
			new TmagServiceSetup(driver).languageSel(language);
			new TmagServiceSetup(driver).prepaidHandsetSelection();
		} catch (Exception e) {
			MatcherAssert.assertThat("Language  Selection Service" + e.getMessage(), false);
			throw new RuntimeException(e);
		}
	}

	public void selectTenderType(String tenderType) {
		try {
			new PosCustomerInformation(driver).getItemEntry();
			new POSEmailCapturePrepaid(driver).testLease(tenderType);
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed at Tender Type Selection" + e.getMessage(), false);
			throw new RuntimeException(e);
		}
	}

	public void amountValueSelection() {
		try {
			new POSEmailCapturePrepaid(driver).posAmountValueSelection();
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed at Amount Value Selection" + e.getMessage(), false);
			throw new RuntimeException(e);
		}
	}

	public void addTenderAndComplete() {
		try {
			new POSEmailCapturePrepaid(driver).addTender();
		} catch (Exception e) {
			MatcherAssert.assertThat("Failed at Tender" + e.getMessage(), false);
			throw new RuntimeException(e);
		}
	}

	public void storeOpenandTillOpen() {
		try {
			log("TMAG Store and till opening process started");
			new TmagHomePage(driver).validateStoreAndTill().clickPrepaidMenuLnk().updateURL();
			new PrepaidMenuPage(driver).clickPrepaidPhone();
		} catch (Exception e) {
			log("TMAG Store and till opening process failed");
			MatcherAssert.assertThat("Failed to open store and till" + e.getMessage(), false);
		}
	}
}